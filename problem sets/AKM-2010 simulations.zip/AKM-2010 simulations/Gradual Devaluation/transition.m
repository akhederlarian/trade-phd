T=24;  % periods we wait for weights to converge

%generate grid of sbtates

sgrid=nodeunif(501,smin(1),smax(1));
edges=[sgrid(1);[sgrid(2:end)+sgrid(1:end-1)]/2];
K=511; 
demand=nodeunif(K,1e-7,1-1e-7);  %start with equidistributed sequence
demand=norminv(demand,0,sqrt(vbar));
demand=smax(2)*(demand>smax(2))+smin(2)*(demand<smin(2))+demand.*(demand>=smin(2)&demand<=smax(2));
edgesd=[demand(1:end-1)-sqrt(eps);demand(end)];

e=demand;
w=1/length(demand)*ones(size(demand));

state=gridmake(sgrid,e);

v=funeval(c_vx,fspace,state);
    
    v1=v(:,1);
    v2=v(:,2);
    x1=v(:,3:4);
    x2=v(:,5);
   
    psim=(x1(:,1).*(v1>=v2)+x2.*(v1<v2));
    isim=(x1(:,2).*(v1>=v2));
    stock=state(:,1);
    sales=min([exp(state(:,2)).*(psim./Pm).^(-gamma).*Cm,stock],[],2);
    ssim=(1-delta)*(stock-sales+isim);

wz=1/length(sgrid)*ones(length(sgrid),1);  %guess weights on ewach of the points in sgrid


P=zeros(T,1);
Pa=P;
Fracorder=P;
Meanorder=P;
Imports=P;
Sales=P;
Inv=P;
IS=P;



for t=1:T
    
  wnew=wz;
  ww=gridmake(wnew,w); ww=ww(:,1).*ww(:,2);


  
 wjunk=hist2(ssim,state(:,2),edges,edgesd,ww);
 wz=sum(wjunk,2);
 
  
fprintf('%4i %6.2e %6.2e %6.2e\n',[t,norm(wz-wnew),mean(abs(wnew(wnew>1e-2|wz>1e-2)-wz(wnew>1e-2|wz>1e-2))./wz(wnew>1e-2|wz>1e-2)),...
    mean(abs(wnew(wnew>1e-4|wz>1e-4)-wz(wnew>1e-4|wz>1e-4))./wz(wnew>1e-4|wz>1e-4))]);


P(t)=(ww'*psim.^(1-gamma)).^(1/(1-gamma));
Fracorder(t)=ww'*(isim>1e-5);
Imports(t)=ww'*isim;

end

P=P(end-4:end);
Fracorder=Fracorder(end-4:end);
Imports=Imports(end-4:end);

save calm wz P Fracorder Imports 

argentina=log([1.090041013
1.341862406
1.469594375
1.560852883
1.586380119
1.535274016
1.479186745
1.455687893
1.4047517
1.40996879
1.372868032
1.361596593
1.306190743
1.282771044
1.274730061
1.252215543
1.216663318
1.202755324
1.180730908
1.194563543
1.200674762
1.175128816
1.15884305]/0.999997472);


for month=1:size(argentina,1)

    save argentinamonth argentina month
    
    start_crisis;
    load calm 
    wzold=wz;
    
sgrid=nodeunif(501,smin(1),smax(1));
edges=[sgrid(1);[sgrid(2:end)+sgrid(1:end-1)]/2];

K=511; 

demand=nodeunif(K,1e-7,1-1e-7);                 %   start with equidistributed sequence
demand=norminv(demand,0,sqrt(vbar));
demand=smax(2)*(demand>smax(2))+smin(2)*(demand<smin(2))+demand.*(demand>=smin(2)&demand<=smax(2));
edgesd=[demand(1:end-1)-sqrt(eps);demand(end)];

e=demand;
w=1/length(demand)*ones(size(demand));

state=gridmake(sgrid,e);

v=funeval(c_vx,fspace,state);
    

    v1=v(:,1);
    v2=v(:,2);
    x1=v(:,3:4);
    x2=v(:,5);
   
    psim=(x1(:,1).*(v1>=v2)+x2.*(v1<v2));
    isim=(x1(:,2).*(v1>=v2));
    stock=state(:,1);
    sales=min([exp(state(:,2)).*(psim./Pm).^(-gamma).*Cm,stock],[],2);
    ssim=(1-delta)*(stock-sales+isim);
    
  wnew=wz;
  ww=gridmake(wnew,w); ww=ww(:,1).*ww(:,2);

   wjunk=hist2(ssim,state(:,2),edges,edgesd,ww);
   wz=sum(wjunk,2);

P_c=(ww'*psim.^(1-gamma)).^(1/(1-gamma));
Fracorder_c=ww'*(isim>1e-5);
Imports_c=ww'*isim;

P=[P;P_c]
Fracorder=[Fracorder;Fracorder_c]
Imports=[Imports;Imports_c]

save calm wz P Fracorder Imports; 

end



