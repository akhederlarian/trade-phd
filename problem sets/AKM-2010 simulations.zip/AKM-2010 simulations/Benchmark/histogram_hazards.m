

%compute hazard and histogram
if 0    %compute Ss rules
     
  K1=50000;
  K2=100;
  state=gridmake(nodeunif(K,smin(1),smax(1)),nodeunif(K2,-1,1));
  v=funeval(c_vx(:,1:2),fspace,state);
  adj=v(:,1)>v(:,2);
  cutoff=zeros(K2,1);   %for each v, compute cutoff adjustment
  gridv=unique(state(:,2));
  for i=1:K2
      if any(state(:,2)==gridv(i)&adj==0)
   cutoff(i)=min(state(state(:,2)==gridv(i)&adj==0,1));   
      end
  end
  
else    % compute hazards
   
invent=vec(ssim(50:end-1,:));
import=vec(isim(51:end,:));

[f,xnode] = hist(invent,25);

adj=vec(import>1e-2);
haz=zeros(length(xnode),1);

for  i=1:length(xnode)
  
    if  i>1
        index=find(invent>=xnode(i-1) & invent < xnode(i));
     else
        index=find(invent<xnode(i));
    end

haz(i)=length(find(adj(index)==1))/length(index);

end
    
end
    
    figure(1)
    subplot(2,1,2);
    bar(xnode/1.55,f/max(f),1);
    hold on
    plot(xnode/1.55,haz,'r');
    


% break
% 
% 
% 
% %compute a Herfhindhal index
% 
% inv=inv(end-95:end,:);
% 
% annualinv=zeros(12,size(inv,1)/12,K);
% HH=zeros(size(inv,1)/12,K);
% for i=1:K
% annualinv(:,:,i)=reshape(inv(:,i),12,size(inv,1)/12);
% HH(:,i)=sum((annualinv(:,:,i)./repmat(sum(annualinv(:,:,i)),12,1)).^2)';
% 
% end
% 
% sinv=-sort(-abs(annualinv),1);
% %fraction accounted for by top month
% f1=mean(mean(sum(sinv(1:1,:,:),1)./sum(sinv(:,:,:))));
% f2=mean(mean(sum(sinv(1:2,:,:),1)./sum(sinv(:,:,:))));
% f3=mean(mean(sum(sinv(1:3,:,:),1)./sum(sinv(:,:,:))));
% f4=mean(mean(sum(sinv(1:4,:,:),1)./sum(sinv(:,:,:))));
% f5=mean(mean(sum(sinv(1:5,:,:),1)./sum(sinv(:,:,:))));
% 
% HH(isnan(HH))=999;  %if no trade during that year
% HH(isinf(HH))=999;
% meanHH=mean(mean(HH(HH~=999))');
% medianHH=median(mean(HH(HH~=999))');
% fpos=median(mean(inv>0.1)');
% 
% fprintf('Mean Herfhindhal                      = %9.2f \n',meanHH);
% fprintf('Median Herfhindhal                    = %9.2f \n',medianHH);
% fprintf('Fraction with positive exports        = %9.2f \n',fpos);
% fprintf('Fraction accounted by top 1 month     = %9.2f \n',f1);
% fprintf('Fraction accounted by top 2 month     = %9.2f \n',f2);
% fprintf('Fraction accounted by top 3 month     = %9.2f \n',f3);
% fprintf('Fraction accounted by top 4 month     = %9.2f \n',f4);
% fprintf('Fraction accounted by top 5 month     = %9.2f \n',f5);
% ssim(1:104,:)=[];
% isim(1:104,:)=[];
% sales(1:104,:)=[];
% 
% 
% fprintf('Monthly inventory-sales ratios (mean) = %9.2f \n',mean(vec(ssim./sales)));
% fprintf('Monthly inventory-sales ratio (median)= %9.2f \n',median(vec(ssim./sales)));
% fprintf('Annual inventory-purchase ratio (mean)= %9.2f \n',mean(vec(ssim))./mean(vec(isim))/12);
% 
% %let's do it exactly as in the model
% T=size(isim,1);
% annualpurch=reshape(isim,12,T/12,K);
% totalannualpurch=sum(annualpurch);
% annualinv=reshape(ssim,12,T/12,K);
% totalannualinv=(annualinv(1,:,:)+annualinv(end,:,:))/2;
% george=mean(vec(totalannualinv(totalannualpurch>0)./totalannualpurch(totalannualpurch>0)));
% fprintf('Annual inventory-purchase ratio as in data= %9.2f \n',george);
% figure(1)
% subplot(2,1,1)
% hist(vecstock,30);
% hold on
% plot(xnode,haz/10);
% break
% ergcalm=ssim(end,:)';
% save ergcalm ergcalm;
% %clear;
% % figure(2)
% % 
% % subplot(1,3,1);
% % plot((1:1:100)'-100,mean(psim'.^(1-gamma)).^(1/(1-gamma)));
% % title('prices')
% % subplot(1,3,2);
% % inv=ssim(2:end,:)+sales(2:end,:)-ssim(1:end-1,:);
% % load ergcalm;
% % inv=[ssim(1,:)+sales(1,:)-ergcalm',;inv];
% % plot((1:1:100)'-100,mean(psim'.*inv'));
% % title('real inventory purchases')
% % subplot(1,3,3);
% % plot((1:1:100)'-100,mean(inv'>.01))
% % title('fraction exporting')
% % %break
% 
% load cooper_crisis;
% inv=ssim(2:end,:)+sales(2:end,:)-ssim(1:end-1,:);
% 
% %compute hazard and histogram
% vecstock=vec(ssim(101:end-1,:));
% [f,xnode] = hist(vecstock,30);
% xnode=nodeunif(30,0,max(vecstock));
% %xnode(1)=0;
% adj=vec(inv(101:end,:)>1e-2);
% haz=zeros(length(xnode),1);
% for  i=1:length(xnode)
%     if i>1
%     index=find(vecstock>=xnode(i-1)&vecstock<xnode(i));
% else
%     index=find(vecstock<xnode(i));
% end
% 
% haz(i)=length(find(adj(index)==1))/length(index);
% 
% end
% 
% figure(1)
% subplot(2,1,2)
% hist(vecstock,30);
% hold on
% plot(xnode,haz/10);
% 
% 
% T=30;
% K=100000;
% randn('state',0);
% psim=zeros(T,K);
% ssim=zeros(T,K);
% isim=zeros(T,K);
% sales=zeros(T,K);
% shock=randn(T,K)*sqrt(vbar);
% shock=shock;
% shock=smax(2)*(shock>smax(2))+smin(2)*(shock<smin(2))+shock.*(shock>=smin(2)&shock<=smax(2));
% 
% load ergcalm;
% for t=1:T
%     t
%     if t==1
%         state=[nodeunif(K,smin(1),smax(1)),shock(1,:)'];  %give them enough not to adjust: twice their demand shock
%        state=[ergcalm.^scale,shock(1,:)'];
%            
%     else
%         state=[(ssim(t-1,:)').^(scale),shock(t,:)'];
%     end
%     
%     v=funeval(c1(:,4:5),fspace1,state);
%     v1=v(:,1);
%     v2=v(:,2);
%     x=funeval(c1(:,1:3),fspace1,state);
%     x1=x(:,1:2);
%     x2=x(:,3);
%    
%     psim(t,:)=(x1(:,1).*(v1>=v2)+x2.*(v1<v2))';
%     isim(t,:)=(x1(:,2).*(v1>=v2))';
%     stock=state(:,1).^(1/scale);
%     sales(t,:)=min([[exp(shock(t,:)).*(psim(t,:)./Pm).^(-gamma).*Cm]',stock],[],2)';
%     
%     ssim(t,:)=(stock+isim(t,:)'-sales(t,:)')';
%     
% end
% 
% figure(2)
% subplot(1,3,1);
% hold on;
% plot((1:1:T)',mean(psim'.^(1-gamma)).^(1/(1-gamma)));
% title('prices')
% subplot(1,3,2);
% hold on;
% inv=ssim(2:end,:)+sales(2:end,:)-ssim(1:end-1,:);
% load ergcalm;
% inv=[ssim(1,:)+sales(1,:)-ergcalm',;inv];
% plot((1:1:T)',mean(psim'.*inv'));
% title('real inventory purchases')
% subplot(1,3,3);
% hold on;
% plot((1:1:T)',mean(inv'>.01))
% title('fraction exporting')