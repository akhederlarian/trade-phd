function [Prices,Fractions,Meanorders,Imports,Sales,Invs]=transition_delta(s_delta)

global beta delta smin smax gamma wss f Pm Cm guess;

%Parameters
delta=s_delta;

%1: Preferences

beta=.94^(1/12);                 %discount factor
gamma=1.5;                       %elasticity of substitution between H and F

%2: Technology

wss=(gamma-1)/gamma ;           %initial price of imports that importers face

%3: Uncertainty

vbar=1.15^2;                     %variance of Gaussian demand shocks

%4: Adjustment cost

f=0.095;                        %fraction of revenue lost when importing

Cm=1;                           %we call this f in the notes. 
Pm=1;                           %we call this p in the .tex notes.
                                %initial price of imports that importers face

%express menu cost in terms of SS revenue
p=gamma/(gamma-1)*wss;
Rev=p.*(p/Pm).^(-gamma)*Cm;

                               
%Discretize random variables

k=51;
[e,w]=qnwnorm(k,0,vbar);
w=w(e<norminv(.999,0,sqrt(vbar))&e>norminv(.001,0,sqrt(vbar)));
e=e(e<norminv(.999,0,sqrt(vbar))&e>norminv(.001,0,sqrt(vbar)));
w=w/sum(w);


%Bounds for state-space
smin=0.01; 
smax=21;
smin=[smin,e(1)];                       
smax=[smax,e(end)];


%Approximation family:
n=[31,21];

scale=1-1/gamma;                %use this scale factor to put more nodes in region where stuff is non-linear

fspace=fundef({'spli',nodeunif(n(1),smin(1).^scale,smax(1).^scale).^(1/scale),0,3},...
              {'lin', nodeunif(n(2),smin(2),smax(2)),0});


Phi=funbasx(fspace);                          %2 value functions
grid=funnode(fspace);                         
s=gridmake(grid);                             


%Guess value function and decision rules:
reward=1/gamma;
stock=s(:,1);
va=wss*stock+exp(s(:,2))./gamma+beta*reward/(1-beta);
c=funfitxy(fspace,Phi,[va,va,va]);
x=[ones(length(s),1)*1.5,3*ones(length(s),1)];
guess=x(:,1);
ns=length(s);


%Few rounds of function iteration using golden search

%load c;
for it=1:3
 
cnew=c;

[v1,v2] = saveBelmax(c,fspace,s,e,w);
c(:,1:2)=funfitxy(fspace,s,[v1,v2]);
v3=valfunc3(c,fspace,s,[],e,w);
c(:,3)=funfitxy(fspace,s,[v3]);
vold=funeval(cnew,fspace,s);
vnew=funeval(c,fspace,s);


%fprintf('%4i %6.2e\n',[it,norm(vold-vnew)]);

if norm(vold-vnew)<1e-5, break, end
end
    

%Few rounds of Newton using golden search
c=vec(c);
for it=1:30
  cnew=c;  
[bel, beljac] =solvebel(cnew,fspace,s,e,w);
c=cnew-(beljac\bel);                               
%compare old with new

vold=funeval([cnew(1:ns,:),cnew(ns+1:2*ns,:),cnew(2*ns+1:3*ns,:)],fspace,s);
vnew=funeval([c(1:ns,:),c(ns+1:2*ns,:),c(2*ns+1:3*ns,:)],fspace,s);

%fprintf('%4i %6.2e\n',[it,norm(vold-vnew)]);  %report difference

if norm(vold-vnew)<1e-7, break, end
end

clear beljac

%put coefficients back in 3 columns 
c=[c(1:ns,:),c(ns+1:2*ns,:),c(2*ns+1:3*ns,:)];
cnew=c;
save c c


n=[51,31];
scale=1;
scale=1-1/gamma;
fspacenew=fundef({'lin',nodeunif(n(1),smin(1).^scale,smax(1).^scale).^(1/scale),0},...
                 {'lin', nodeunif(n(2),smin(2),smax(2)),0});

s=funnode(fspacenew);
s=gridmake(s);
[v1,v2,v3,x1,x2]=saveBelmax(c,fspace,s,e,w);   %solve the firms' problem given correct coefficient
c_vx=funfitxy(fspacenew,s,[v1,v2,x1,x2]);         %the reason I invoked saveBelmax here is to get optimal prices in state-space
fspaceold=fspace;
fspace=fspacenew;

T=24;  %periods we wait for weights to converge

%generate grid of sbtates

sgrid=nodeunif(501,smin(1),smax(1));
edges=[sgrid(1);[sgrid(2:end)+sgrid(1:end-1)]/2];
K=511; 
demand=nodeunif(K,1e-7,1-1e-7);  %start with equidistributed sequence
demand=norminv(demand,0,sqrt(vbar));
demand=smax(2)*(demand>smax(2))+smin(2)*(demand<smin(2))+demand.*(demand>=smin(2)&demand<=smax(2));
edgesd=[demand(1:end-1)-sqrt(eps);demand(end)];

e=demand;
w=1/length(demand)*ones(size(demand));

state=gridmake(sgrid,e);

v=funeval(c_vx,fspace,state);
    
    v1=v(:,1);
    v2=v(:,2);
    x1=v(:,3:4);
    x2=v(:,5);
   
    psim=(x1(:,1).*(v1>=v2)+x2.*(v1<v2));
    isim=(x1(:,2).*(v1>=v2));
    stock=state(:,1);
    sales=min([exp(state(:,2)).*(psim./Pm).^(-gamma).*Cm,stock],[],2);
    ssim=(1-delta)*(stock-sales+isim);

wz=1/length(sgrid)*ones(length(sgrid),1);  %guess weights on ewach of the points in sgrid


P=zeros(T,1);
Pa=P;
Fracorder=P;
Meanorder=P;
Imports=P;
Sales=P;
Inv=P;
IS=P;


for t=1:T
    
  wnew=wz;
  ww=gridmake(wnew,w); ww=ww(:,1).*ww(:,2);

 wjunk=hist2(ssim,state(:,2),edges,edgesd,ww);
 wz=sum(wjunk,2);
 
 
%fprintf('%4i %6.2e %6.2e %6.2e\n',[t,norm(wz-wnew),mean(abs(wnew(wnew>1e-2|wz>1e-2)-wz(wnew>1e-2|wz>1e-2))./wz(wnew>1e-2|wz>1e-2)),...
%    mean(abs(wnew(wnew>1e-4|wz>1e-4)-wz(wnew>1e-4|wz>1e-4))./wz(wnew>1e-4|wz>1e-4))]);


P(t)=(ww'*psim.^(1-gamma)).^(1/(1-gamma));
Pa(t)=ww'*psim;
Fracorder(t)=ww'*(isim>1e-5);
Imports(t)=ww'*isim;
Meanorder(t)=Imports(t)/Fracorder(t);
Sales(t)=ww'*sales;
Inv(t)=ww'*ssim;

end


save calm wz P Fracorder Imports Meanorder Sales Inv Pa


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Parameters


%crisis: 
deval=0.5;
mshare=0.75;
wss=wss*exp(deval*mshare);
beta=.70^(1/12);                             
Cm=0.85;


                            
%Discretize random variables

k=51;
[e,w]=qnwnorm(k,0,vbar);
w=w(e<norminv(.999,0,sqrt(vbar))&e>norminv(.001,0,sqrt(vbar)));
e=e(e<norminv(.999,0,sqrt(vbar))&e>norminv(.001,0,sqrt(vbar)));
w=w/sum(w);


%Bounds for state-space
smin=0.01; 
smax=21;
smin=[smin,e(1)];                       
smax=[smax,e(end)];


%Approximation family:
n=[31,21];

scale=1-1/gamma;                %use this scale factor to put more nodes in region where stuff is non-linear

fspace=fundef({'spli',nodeunif(n(1),smin(1).^scale,smax(1).^scale).^(1/scale),0,3},...
              {'lin', nodeunif(n(2),smin(2),smax(2)),0});


Phi=funbasx(fspace);                          %2 value functions
grid=funnode(fspace);                         
s=gridmake(grid);                             


%Guess value function and decision rules:
reward=1/gamma;
stock=s(:,1);
va=wss*stock+exp(s(:,2))./gamma+beta*reward/(1-beta);
c=funfitxy(fspace,Phi,[va,va,va]);
x=[ones(length(s),1)*1.5,3*ones(length(s),1)];
guess=x(:,1);
ns=length(s);


%Few rounds of function iteration using golden search

%load c;
for it=1:3
 
cnew=c;

[v1,v2] = saveBelmax(c,fspace,s,e,w);
c(:,1:2)=funfitxy(fspace,s,[v1,v2]);
v3=valfunc3(c,fspace,s,[],e,w);
c(:,3)=funfitxy(fspace,s,[v3]);
vold=funeval(cnew,fspace,s);
vnew=funeval(c,fspace,s);


%fprintf('%4i %6.2e\n',[it,norm(vold-vnew)]);

if norm(vold-vnew)<1e-5, break, end
end
    

%Few rounds of Newton using golden search
c=vec(c);
for it=1:30
  cnew=c;  
[bel, beljac] =solvebel(cnew,fspace,s,e,w);
c=cnew-(beljac\bel);                               
%compare old with new

vold=funeval([cnew(1:ns,:),cnew(ns+1:2*ns,:),cnew(2*ns+1:3*ns,:)],fspace,s);
vnew=funeval([c(1:ns,:),c(ns+1:2*ns,:),c(2*ns+1:3*ns,:)],fspace,s);

%fprintf('%4i %6.2e\n',[it,norm(vold-vnew)]);  %report difference

if norm(vold-vnew)<1e-7, break, end
end

clear beljac

%put coefficients back in 3 columns 
c=[c(1:ns,:),c(ns+1:2*ns,:),c(2*ns+1:3*ns,:)];
cnew=c;
save c c


n=[51,31];

scale=1-1/gamma;
fspacenew=fundef({'lin',nodeunif(n(1),smin(1).^scale,smax(1).^scale).^(1/scale),0},...
                 {'lin', nodeunif(n(2),smin(2),smax(2)),0});

s=funnode(fspacenew);
s=gridmake(s);
[v1,v2,v3,x1,x2]=saveBelmax(c,fspace,s,e,w);   %solve the firms' problem given correct coefficient
c_vx=funfitxy(fspacenew,s,[v1,v2,x1,x2]);         %the reason I invoked saveBelmax here is to get optimal prices in state-space
fspaceold=fspace;
fspace=fspacenew;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load calm
wzold=wz;

T=18;  %periods we wait for weights to converge

%generate grid of sbtates

sgrid=nodeunif(501,smin(1),smax(1));
edges=[sgrid(1);[sgrid(2:end)+sgrid(1:end-1)]/2];
K=511; 
demand=nodeunif(K,1e-7,1-1e-7);  %start with equidistributed sequence
demand=norminv(demand,0,sqrt(vbar));
demand=smax(2)*(demand>smax(2))+smin(2)*(demand<smin(2))+demand.*(demand>=smin(2)&demand<=smax(2));
edgesd=[demand(1:end-1)-sqrt(eps);demand(end)];

e=demand;
w=1/length(demand)*ones(size(demand));

state=gridmake(sgrid,e);

v=funeval(c_vx,fspace,state);
    
    v1=v(:,1);
    v2=v(:,2);
    x1=v(:,3:4);
    x2=v(:,5);
   
    psim=(x1(:,1).*(v1>=v2)+x2.*(v1<v2));
    isim=(x1(:,2).*(v1>=v2));
    stock=state(:,1);
    sales=min([exp(state(:,2)).*(psim./Pm).^(-gamma).*Cm,stock],[],2);
    ssim=(1-delta)*(stock-sales+isim);


P_c=zeros(T,1);
Pa_c=P_c;
Fracorder_c=P_c;
Meanorder_c=P_c;
Imports_c=P_c;
Sales_c=P_c;
Inv_c=P_c;
IS_c=P_c;


for t=1:T
    
  wnew=wz;
  ww=gridmake(wnew,w); ww=ww(:,1).*ww(:,2);

 wjunk=hist2(ssim,state(:,2),edges,edgesd,ww);
 wz=sum(wjunk,2);

 
 
%fprintf('%4i %6.2e %6.2e %6.2e\n',[t,norm(wz-wnew),mean(abs(wnew(wnew>1e-2|wz>1e-2)-wz(wnew>1e-2|wz>1e-2))./wz(wnew>1e-2|wz>1e-2)),...
 %   mean(abs(wnew(wnew>1e-4|wz>1e-4)-wz(wnew>1e-4|wz>1e-4))./wz(wnew>1e-4|wz>1e-4))]);


P_c(t)=(ww'*psim.^(1-gamma)).^(1/(1-gamma));
Pa_c(t)=ww'*psim;
Fracorder_c(t)=ww'*(isim>1e-5);
Imports_c(t)=ww'*isim;
Meanorder_c(t)=Imports_c(t)/Fracorder_c(t);
Sales_c(t)=ww'*sales;
Inv_c(t)=ww'*ssim;

end


Prices=[P(end);P_c];
Fractions=[Fracorder(end);Fracorder_c];
Meanorders=[Meanorder(end);Meanorder_c];
Imports=[Imports(end);Imports_c];
Sales=[Sales(end);Sales_c];
Invs=[Inv(end);Inv_c];


