clear;
clc;

load depreciationdata;
deltas=data;
durab=2*log(1/2)./log(1-deltas);

scaled=1/5;
fspace_delta=fundef({'spli',nodeunif(35,min(deltas)^scaled,.5^scaled).^(1/scaled),0,3});


grid_delta=funnode(fspace_delta);                         
s_delta=gridmake(grid_delta);   

Prices=zeros(19,length(s_delta));

for j=1:length(s_delta);
    tic
j
[Prices(:,j),Fractions(:,j),Meanorders(:,j),Imports(:,j),Sales(:,j),Invs(:,j)]=transition_delta(s_delta(j));    
    toc
    
end

%project and do the regressions

Phi_delta=funbas(fspace_delta);  
c1=Phi_delta\log(Prices(2,:)./Prices(1,:))';
c2=Phi_delta\log(Prices(3,:)./Prices(1,:))';
c3=Phi_delta\log(Prices(4,:)./Prices(1,:))';
c6=Phi_delta\log(Prices(7,:)./Prices(1,:))';
c9=Phi_delta\log(Prices(10,:)./Prices(1,:))';
c12=Phi_delta\log(Prices(13,:)./Prices(1,:))';


deltas=deltas(deltas<.5);
durab=2*log(1/2)./log(1-deltas);
pass1=funeval(c1,fspace_delta,deltas);
pass2=funeval(c2,fspace_delta,deltas);
pass3=funeval(c3,fspace_delta,deltas);
pass12=funeval(c12,fspace_delta,deltas);


reg=ols(pass1,[ones(size(pass1)),log(durab)]);
[reg.beta,reg.tstat]

reg=ols(pass2,[ones(size(pass2)),log(durab)]);
[reg.beta,reg.tstat]

reg=ols(pass3,[ones(size(pass3)),log(durab)]);
[reg.beta,reg.tstat]

reg=ols(pass12,[ones(size(pass12)),log(durab)]);
[reg.beta,reg.tstat]