% VALFUNC  Evaluates Bellman Optimand
  function v = valfunc2(c,fspace,s,x,e,w)
  
global beta;
 
      g = feval('menufun','g2',s,x,[],[]);
      v = feval('menufun','f2',s,x,[],[])+beta*funeval(c(:,3),fspace,g);