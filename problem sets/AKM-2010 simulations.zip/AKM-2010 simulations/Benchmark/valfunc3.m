% VALFUNC  Evaluates Bellman Optimand
  function v = valfunc3(c,fspace,s,x,e,w)
  

K  = length(w);
ns = size(s,1);


     v = 0;
     
      for k=1:K
        kk = k + zeros(ns,1); 
     
        g = feval('menufun','g3',s,[],e(kk,:),w);
        v  = v  + w(k).*max(funeval(c(:,1:2),fspace,g),[],2); 
     
      end