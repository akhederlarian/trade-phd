% VALFUNC  Evaluates Bellman Optimand
  function v = valfunc1(c,fspace,s,x,e,w)
  
global beta;
 
      g = feval('menufun','g1',s,x,[],[]);
      v = feval('menufun','f1',s,x,[],[])+beta*funeval(c(:,3),fspace,g);