T=50;  %periods we wait for weights to converge

%generate grid of sbtates

sgrid=nodeunif(301,smin(1),smax(1));
edges=[sgrid(1);[sgrid(2:end)+sgrid(1:end-1)]/2];
K=501; 
demand=nodeunif(K,1e-7,1-1e-7);  %start with equidistributed sequence
demand=norminv(demand,0,sqrt(vbar));
demand=smax(2)*(demand>smax(2))+smin(2)*(demand<smin(2))+demand.*(demand>=smin(2)&demand<=smax(2));
edgesd=[demand(1:end-1)-sqrt(eps);demand(end)];

e=demand;
w=1/length(demand)*ones(size(demand));

state=gridmake(sgrid,e);

v=funeval(c_vx,fspace,state);
    
    v1=v(:,1);
    v2=v(:,2);
    x1=v(:,3:4);
    x2=v(:,5);
   
    psim=(x1(:,1).*(v1>=v2)+x2.*(v1<v2));
    isim=(x1(:,2).*(v1>=v2));
    stock=state(:,1);
    sales=min([exp(state(:,2)).*(psim./Pm).^(-gamma).*Cm,stock],[],2);
    ssim=(1-delta)*(stock-sales+isim);

wz=1/length(sgrid)*ones(length(sgrid),1);  %guess weights on ewach of the points in sgrid


P=zeros(T,1);
Fracorder=P;
Meanorder=P;
Imports=P;
Sales=P;
Inv=P;
IS=P;


for t=1:T
    
  wnew=wz;
  ww=gridmake(wnew,w); ww=ww(:,1).*ww(:,2);

 wjunk=hist2(ssim,state(:,2),edges,edgesd,ww);
 wz=sum(wjunk,2);
 wjunk=reshape(wjunk,size(wjunk,1)*size(wjunk,2),1);
 
 wguess=reshape(wjunk,size(wjunk,1)*size(wjunk,2),1);
 
 
fprintf('%4i %6.2e %6.2e %6.2e\n',[t,norm(wz-wnew),mean(abs(wnew(wnew>1e-2|wz>1e-2)-wz(wnew>1e-2|wz>1e-2))./wz(wnew>1e-2|wz>1e-2)),...
    mean(abs(wnew(wnew>1e-4|wz>1e-4)-wz(wnew>1e-4|wz>1e-4))./wz(wnew>1e-4|wz>1e-4))]);


P(t)=(wjunk'*psim.^(1-gamma)).^(1/(1-gamma));
Fracorder(t)=wjunk'*(isim>1e-5);
Imports(t)=wjunk'*isim;
Meanorder(t)=Imports(t)/Fracorder(t);
Sales(t)=wjunk'*sales;
Inv(t)=wjunk'*ssim;

end

   

