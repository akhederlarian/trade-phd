function [v1,v2,v3,xadjust,xnadjust,v11,v12,v13,v21,v22,v23,v31,v32,v33]=saveBelmax(c,fspace,s,e,w)


global beta;

ns=length(s);


solve1;
xadjust=x;
v1=valfunc1(c,fspace,s,xadjust,e,w);

solve2;
xnadjust=x;
v2=valfunc2(c,fspace,s,xnadjust,e,w);

v3=valfunc3(c,fspace,s,[],e,w);


if nargout>5
    
      v11=zeros(ns,ns);   v12=v11;  v13=v11;
      v21=zeros(ns,ns);   v22=v21;  v23=v21;
      v31=zeros(ns,ns);   v32=v31;  v33=v31;
      
      
        g = feval('menufun','g1',s,xadjust,[],w);
        v13 = beta*funbas(fspace,g);    
        
        g = feval('menufun','g2',s,xnadjust,[],w);
        v23 = beta*funbas(fspace,g);          
        
        
    for k=1:length(w)   % go over all possible values e (discretized distribution of disturbances) can take
      
        kk = k+zeros(ns,1);
        g=feval('menufun','g3',s,[],e(kk,:),w);

       vint1  = fund(c(:,1),fspace,g,1);        %check which one is higher
       vint2  = fund(c(:,2),fspace,g,1);
       
       c1=vint1>=vint2;
       c2=vint2>vint1;
       
        v31 = v31 + w(k)*(funbas(fspace,g).*repmat(c1,1,ns));   
        v32 = v32 + w(k)*(funbas(fspace,g).*repmat(c2,1,ns));  
        
    end
end


