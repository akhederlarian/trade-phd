
inv=isim;

%compute a Herfhindhal index

inv=inv(end-95:end,:);

annualinv=zeros(12,size(inv,1)/12,K);
HH=zeros(size(inv,1)/12,K);
for i=1:K
annualinv(:,:,i)=reshape(inv(:,i),12,size(inv,1)/12);
HH(:,i)=sum((annualinv(:,:,i)./repmat(sum(annualinv(:,:,i)),12,1)).^2)';

end

sinv=-sort(-abs(annualinv),1);
%fraction accounted for by top month
f1=mean(mean(sum(sinv(1:1,:,:),1)./sum(sinv(:,:,:))));
f2=mean(mean(sum(sinv(1:2,:,:),1)./sum(sinv(:,:,:))));
f3=mean(mean(sum(sinv(1:3,:,:),1)./sum(sinv(:,:,:))));
f4=mean(mean(sum(sinv(1:4,:,:),1)./sum(sinv(:,:,:))));
f5=mean(mean(sum(sinv(1:5,:,:),1)./sum(sinv(:,:,:))));

HH(isnan(HH))=999;  %if no trade during that year
HH(isinf(HH))=999;
meanHH=mean(mean(HH(HH~=999))');
medianHH=median(mean(HH(HH~=999))');
fpos=median(mean(inv>0.1)');


%fprintf('Median Herfhindhal                    = %9.2f \n',medianHH);
%fprintf('Fraction with positive exports        = %9.2f \n',fpos);
%fprintf('Fraction accounted by top 1 month     = %9.2f \n',f1);
%fprintf('Fraction accounted by top 2 month     = %9.2f \n',f2);
%fprintf('Fraction accounted by top 3 month     = %9.2f \n',f3);
%fprintf('Fraction accounted by top 4 month     = %9.2f \n',f4);
%fprintf('Fraction accounted by top 5 month     = %9.2f \n',f5);
ssim(1:104,:)=[];
isim(1:104,:)=[];
sales(1:104,:)=[];


%fprintf('Monthly inventory-sales ratios (mean) = %9.2f \n',mean(vec(ssim./sales)));
%fprintf('Monthly inventory-sales ratio (median)= %9.2f \n',median(vec(ssim./sales)));
%fprintf('Annual inventory-purchase ratio (mean)= %9.2f \n',mean(vec(ssim))./mean(vec(isim))/12);

%let's do it exactly as in the data
T=size(isim,1);
annualpurch=reshape(isim,12,T/12,K);
totalannualpurch=sum(annualpurch);
annualinv=reshape(ssim,12,T/12,K);
totalannualinv=(annualinv(1,:,:)+annualinv(end,:,:))/2;
george=mean(vec(totalannualinv(totalannualpurch>0)./totalannualpurch(totalannualpurch>0)));

fprintf('Mean Herfhindhal                      = %9.2f \n',meanHH);
fprintf('Annual inventory-purchase ratio       = %9.2f \n',george);
