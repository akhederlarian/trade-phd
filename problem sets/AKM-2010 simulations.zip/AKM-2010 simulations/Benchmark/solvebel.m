function [bel, beljac] =solvebel(c,fspace,s,e,w)


ns=size(s,1);
c=[c(1:ns,:),c(ns+1:2*ns,:),c(2*ns+1:3*ns,:)];




[v1,v2,v3,x1,x2,v11,v12,v13,v21,v22,v23,v31,v32,v33]=saveBelmax(c,fspace,s,e,w);


LHS=funeval(c,fspace,s);                              %left-hand side of Bellman equation

B=funbas(fspace,s);                                             %Miranda calls this the PHI matrix
                                                                   %chebyshev polynomials evaluated at all nodes in state-space
bel=zeros(3*length(s),1);
beljac=zeros(3*length(s),3*length(s));
bel(1:ns)=LHS(:,1)-v1;                                     %LHS-RHS of BEllman equation for adjustment
bel(ns+1:2*ns)=LHS(:,2)-v2;                                 %LHS-RHS of bellman equation for non-adjustment
bel(2*ns+1:3*ns)=LHS(:,3)-v3;                                 %LHS-RHS of bellman equation for non-adjustment


beljac(1:ns,:)=[B,zeros(ns,ns),zeros(ns,ns)]-[v11,v12,v13];      %derivative wrt. c
beljac(ns+1:2*ns,:)=[zeros(ns,ns),B,zeros(ns,ns)]-[v21,v22,v23];  %derivative wrt.c
beljac(2*ns+1:3*ns,:)=[zeros(ns,ns),zeros(ns,ns),B]-[v31,v32,v33];  %derivative wrt.c
