%joe experiments

start_calm;

c_vx_calm=c_vx;
fspace_calm=fspace;

save calm c_vx_calm fspace_calm

start_crisis;

T=24;
K=150000;
disp('simulating ...')
randn('state',0);

psim=zeros(T,K);
ssim=zeros(T,K);
isim=zeros(T,K);
sales=zeros(T,K);
shock=randn(T,K)*sqrt(vbar);
age=zeros(T,K);

shock=smax(2)*(shock>smax(2))+smin(2)*(shock<smin(2))+shock.*(shock>=smin(2)&shock<=smax(2));
load calm

for t=1:T
   
    
    if t==1
        state=[nodeunif(K,smin(1),smax(1)),shock(1,:)'];  %give them enough not to adjust: twice their demand shock
          
    else
        state=[ssim(t-1,:)',shock(t,:)'];
    end
    
    
    if t<=12
        v=funeval(c_vx_calm,fspace_calm,state);
    else
        v=funeval(c_vx,fspace,state);
    end
    
    v1=v(:,1);
    v2=v(:,2);
    x1=v(:,3:4);
    x2=v(:,5);
   
    if t>1
        age(t,:)=age(t-1,:)+1;
        age(t,:)=age(t,:).*(isim(t,:)==0);
    end
    
    psim(t,:)=(x1(:,1).*(v1>=v2)+x2.*(v1<v2))';
    isim(t,:)=(x1(:,2).*(v1>=v2))';
    stock=state(:,1);
    sales(t,:)=min([[exp(shock(t,:)).*(psim(t,:)./Pm).^(-gamma).*Cm]',stock],[],2)';
    
    ssim(t,:)=((1-delta)*(stock-sales(t,:)'+isim(t,:)'))';
    
    
    
end


P=mean(psim.^(1-gamma),2).^(1/(1-gamma));
Imports=mean(isim,2);
