T=200;
K=15000;
disp('simulating ...')
randn('state',0);

psim=zeros(T,K);
ssim=zeros(T,K);
isim=zeros(T,K);
sales=zeros(T,K);
shock=randn(T,K)*sqrt(vbar);


shock=smax(2)*(shock>smax(2))+smin(2)*(shock<smin(2))+shock.*(shock>=smin(2)&shock<=smax(2));

for t=1:T
   
    
    if t==1
        state=[nodeunif(K,smin(1),smax(1)),shock(1,:)'];  %give them enough not to adjust: twice their demand shock
          
    else
        state=[ssim(t-1,:)',shock(t,:)'];
    end
    
    v=funeval(c_vx,fspace,state);
    
    v1=v(:,1);
    v2=v(:,2);
    x1=v(:,3:4);
    x2=v(:,5);
   
    psim(t,:)=(x1(:,1).*(v1>=v2)+x2.*(v1<v2))';
    isim(t,:)=(x1(:,2).*(v1>=v2))';
    stock=state(:,1);
    sales(t,:)=min([[exp(shock(t,:)).*(psim(t,:)./Pm).^(-gamma).*Cm]',stock],[],2)';
    
    ssim(t,:)=((1-delta)*(stock-sales(t,:)'+isim(t,:)'))';
    
end

%statistics