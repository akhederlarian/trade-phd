clear all;
clc;
%input parameters:

global beta delta smin smax gamma wss f Pm Cm guess;

%Parameters

gamma=1.5;                      %elasticity of substitution between H and F
wss=(gamma-1)/gamma ;           %initial price of imports that importers face

delta=.025;                     % rate at which inventory in wharehouse depreciates
vbar=1.15^2;                    % variance of Gaussian demand shocks
f=.095;  

%crisis: 
deval=0.0;
mshare=1;
wss=wss*exp(deval*mshare);
beta=.94^(1/12);                             
Cm=0.85;
Pm=1;


%express menu cost in terms of SS revenue
p=gamma/(gamma-1)*wss;
Rev=p.*(p/Pm).^(-gamma)*Cm;
disp(f/Rev*100);

                               
%Discretize random variables
k=51;
[e,w]=qnwnorm(k,0,vbar);
w=w(e<norminv(.999,0,sqrt(vbar))&e>norminv(.001,0,sqrt(vbar)));
e=e(e<norminv(.999,0,sqrt(vbar))&e>norminv(.001,0,sqrt(vbar)));
w=w/sum(w);

%Bounds for state-space
smin=0.01; 
smax=21;
smin=[smin,e(1)];                       
smax=[smax,e(end)];

%Approximation family:
n=[31,21];

scale=1-1/gamma;                              %use this scale factor to put more nodes in region where stuff is non-linear

fspace=fundef({'spli',nodeunif(n(1),smin(1).^scale,smax(1).^scale).^(1/scale),0,3},...
              {'lin', nodeunif(n(2),smin(2),smax(2)),0});


Phi=funbasx(fspace);                          %2 value functions
grid=funnode(fspace);                         
s=gridmake(grid);                             


%Guess value function and decision rules:
reward=1/gamma;
stock=s(:,1);
va=wss*stock+exp(s(:,2))./gamma+beta*reward/(1-beta);
c=funfitxy(fspace,Phi,[va,va,va]);
x=[ones(length(s),1)*1.5,3*ones(length(s),1)];
guess=x(:,1);
ns=length(s);


%Few rounds of function iteration using golden search

%load c;
for it=1:3
 
cnew=c;

[v1,v2] = saveBelmax(c,fspace,s,e,w);
c(:,1:2)=funfitxy(fspace,s,[v1,v2]);
v3=valfunc3(c,fspace,s,[],e,w);
c(:,3)=funfitxy(fspace,s,[v3]);
vold=funeval(cnew,fspace,s);
vnew=funeval(c,fspace,s);


fprintf('%4i %6.2e\n',[it,norm(vold-vnew)]);

if norm(vold-vnew)<1e-5, break, end
end
    

%Few rounds of Newton using golden search
c=vec(c);
for it=1:30
  cnew=c;  
[bel, beljac] =solvebel(cnew,fspace,s,e,w);
c=cnew-(beljac\bel);                               
%compare old with new

vold=funeval([cnew(1:ns,:),cnew(ns+1:2*ns,:),cnew(2*ns+1:3*ns,:)],fspace,s);
vnew=funeval([c(1:ns,:),c(ns+1:2*ns,:),c(2*ns+1:3*ns,:)],fspace,s);

fprintf('%4i %6.2e\n',[it,norm(vold-vnew)]);  %report difference

if norm(vold-vnew)<1e-7, break, end
end

clear beljac

%put coefficients back in 3 columns 
c=[c(1:ns,:),c(ns+1:2*ns,:),c(2*ns+1:3*ns,:)];
cnew=c;
save c c


n=[51,31]

scale=1-1/gamma;
fspacenew=fundef({'lin',nodeunif(n(1),smin(1).^scale,smax(1).^scale).^(1/scale),0},...
                 {'lin', nodeunif(n(2),smin(2),smax(2)),0});

s=funnode(fspacenew);
s=gridmake(s);
[v1,v2,v3,x1,x2]=saveBelmax(c,fspace,s,e,w);   %solve the firms' problem given correct coefficient
c_vx=funfitxy(fspacenew,s,[v1,v2,x1,x2]);         %the reason I invoked saveBelmax here is to get optimal prices in state-space
fspaceold=fspace;
fspace=fspacenew;

