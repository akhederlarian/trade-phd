Each folder contains files that perform computations described in the paper. 
The "Benchmark" folder contains the main (Benchmark) experiments, the rest perform additional robustness experiments.

I describe the "Benchmark" folder below, the other folders are similar. 

1) 	start.m computes the policy rules / value functions of firms in the Benchmark economy and reports moments. 
   	It also computes the expected value of a firm that is subject to the frictions. This is used to compute the      
	tariff-equivalent of the frictions. To compute the tariff-equivalent one must run start.m in the "Frictionless" folder 
	which computes the value of a firm in a frictionless economy in which the tariff on importrers is equal to tau. One then 
	updates tau iteratively to equate the two valuations.

	start.m calls simulate.m and statistics.m which simulate firm decision rule and compute statistics, respectively. 
	We also call Miranda and Fackler's Compecon library which must be installed on the matlab path before running start.m

2) 	start_calm.m computes the transition in response to a "devaluation". 
    	It first computes decision rules, then (in transition.m) computes the ergodic distribution prior to the devaluation, 
	saves this data (in calm.mat) and then calls start_crisis.m which computes the post-crisis optimal decision rules. 
	One can edit the parameters determining the magnitude of the devaluation, the behavior of the interest rate etc. 
	In start_crisis.m. Finally, transition.m uses several auxiliary files (hist.m, hist2.m) in order to compute the ergodic distribution.


3) 	All other folders are identical. The only exception occurs in the "Gradual Devlatuation anticipated" experiment in which we feed a particular 
	path for omega_t that is known at the moment of the devaluation. We therefore no longer assume that the firms use the post-crisis steady-state 
	decision rules and use instead a shooting algorithm to solve the problem. That is, we guess that the economy converges in K periods, and use 
	backward iteration to compute value functions at each date during the transition. This is accomplished in start_crisis.m at lines 130-135. 

4) 	"Cooper Benchmark" and "Cooper high elasticity" contain the folders used in an earlier draft of the paper where we assumed that the 
	fixed cost is proportional to revenue (a fraction lambda of revenue is lost in periods in which the importer orders). This folders were used to 
	construct Figure 6b in the appendix.