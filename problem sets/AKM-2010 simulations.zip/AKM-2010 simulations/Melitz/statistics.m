
inv=isim;

%compute a Herfhindhal index

inv=inv(end-95:end,:);

annualinv=zeros(12,size(inv,1)/12,K);
HH=zeros(size(inv,1)/12,K);
for i=1:K
annualinv(:,:,i)=reshape(inv(:,i),12,size(inv,1)/12);
HH(:,i)=sum((annualinv(:,:,i)./repmat(sum(annualinv(:,:,i)),12,1)).^2)';

end

sinv=-sort(-abs(annualinv),1);
%fraction accounted for by top month
f1=mean(mean(sum(sinv(1:1,:,:),1)./sum(sinv(:,:,:))));
f2=mean(mean(sum(sinv(1:2,:,:),1)./sum(sinv(:,:,:))));
f3=mean(mean(sum(sinv(1:3,:,:),1)./sum(sinv(:,:,:))));
f4=mean(mean(sum(sinv(1:4,:,:),1)./sum(sinv(:,:,:))));
f5=mean(mean(sum(sinv(1:5,:,:),1)./sum(sinv(:,:,:))));

HH(isnan(HH))=999;  %if no trade during that year
HH(isinf(HH))=999;
meanHH=mean(mean(HH(HH~=999))');
medianHH=median(mean(HH(HH~=999))');
fpos=median(mean(inv>0.1)');



fprintf('Mean Herfhindhal                      = %9.2f \n',meanHH);
