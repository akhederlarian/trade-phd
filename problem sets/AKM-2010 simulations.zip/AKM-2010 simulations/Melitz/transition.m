%simulate crisis

deval=log([0.999997472
    0.999997472
    0.999997472
    0.999997472
    0.999997472
    1.090041013
1.341862406
1.469594375
1.560852883
1.586380119
1.535274016
1.479186745
1.455687893
1.4047517
1.40996879
1.372868032
1.361596593
1.306190743
1.282771044
1.274730061
1.252215543
1.216663318
1.202755324
1.180730908
1.194563543
1.200674762
1.175128816
1.15884305]/0.999997472);

mshare=0.75;

wss=(gamma-1)/gamma*exp(deval*mshare);
Cm=0.85;

p=gamma/(gamma-1)*wss;                                
profit=1/(gamma-1)*(gamma/(gamma-1))^(-gamma)*wss.^(1-gamma)*Cm;
f=0;
T=20;
K=2000000;

psim=zeros(T,K);
isim=zeros(T,K);
sales=zeros(T,K);
shock=randn(T,K)*sqrt(vbar);
profits=zeros(T,K);

for t=1:T
   
    import=exp(shock(t,:))>f/profit(t);
    profits(t,:)=exp(shock(t,:))*profit(t);
    isim(t,:)=exp(shock(t,:)).*(gamma/(gamma-1)*wss(t)).^(-gamma);
    isim(t,:)=isim(t,:).*import;
end