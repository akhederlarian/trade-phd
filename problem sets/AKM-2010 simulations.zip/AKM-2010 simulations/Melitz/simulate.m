T=200;
K=1500000;
disp('simulating ...')
randn('state',0);

psim=zeros(T,K);
isim=zeros(T,K);
sales=zeros(T,K);
shock=randn(T,K)*sqrt(vbar);
profits=zeros(T,K);


for t=1:T
   
    import=exp(shock(t,:))>f/profit;
    profits(t,:)=exp(shock(t,:))*profit;
    isim(t,:)=exp(shock(t,:)).*(gamma/(gamma-1)*wss).^(-gamma);
    isim(t,:)=isim(t,:).*import;
end

%statistics


