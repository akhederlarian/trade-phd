clear all;
clc;

%Parameters

%1: Preferences

beta=.94^(1/12);                % discount factor
gamma=1.5;                      % elasticity of substitution between H and F
wss=(gamma-1)/gamma ;           % initial price of imports that importers face (normalization)


vbar=1.15^2;                    % variance of Gaussian demand shocks
f=1.3;  

Cm=1;                           % we call this f in the notes. 
Pm=1;                           % we call this p in the .tex notes.
                                % initial price of imports that importers face

p=gamma/(gamma-1)*wss;                                
profit=1/(gamma-1)*(gamma/(gamma-1))^(-gamma)*wss^(1-gamma);


simulate
statistics