%second, compute optimal response if change only inventory

% COMPUTE BOUNDS      
[ap,bp]=feval('menufun','bp',s,[],[],[]);
[ai,bi]=feval('menufun','bi',s,[],[],[]);

%WRITE A GOLD SEARCH ALGORITHM HERE to maximize valfunc1(c,fspace,s,x,e,w)


tolp=1e-4;
toli=1e-4;

alpha1 = (3-sqrt(5))/2;
alpha2 = (sqrt(5)-1)/2;


dp  = bp-ap;
x1p = ap+alpha1*dp;
x2p = ap+alpha2*dp;

x1newp=x1p;
x2newp=x2p;

dp = alpha1*alpha2*dp;

di  = bi-ai;
x1i = ai+alpha1*di;
x2i = ai+alpha2*di;

x1newi=x1i;
x2newi=x2i;

di = alpha1*alpha2*di;


f1i = valfunc1(c,fspace,s,[x1p,x1i],e,w);
f2i = valfunc1(c,fspace,s,[x1p,x2i],e,w);

f1inew=f1i;
f2inew=f2i;
x1inew=x1i;
x2inew=x2i;

while di>toli
   
 f1i=f1inew;
 f2i=f2inew;
 x1i=x1inew;
 x2i=x2inew;
    
  di = di*alpha2;
  x2inew=x1i.*(f2i<f1i)+(x2i+di).*(f2i>=f1i);
  f2inew=f1i.*(f2i<f1i)+valfunc1(c,fspace,s,[x1p,x2i+di],e,w).*(f2i>=f1i);
  
  x1inew=(x1i-di).*(f2i<f1i)+x2i.*(f2i>=f1i);
  f1inew=valfunc1(c,fspace,s,[x1p,x1i-di],e,w).*(f2i<f1i)+f2i.*(f2i>=f1i);
  
  end

  xi=x2inew.*(f2inew>=f1inew)+x1inew.*(f2inew<f1inew);

 
  f1p=valfunc1(c,fspace,s,[x1p,xi],e,w);
  
%now, solve for optimal xi given x2p
  
di  = bi-ai;
x1i = ai+alpha1*di;
x2i = ai+alpha2*di;

x1newi=x1i;
x2newi=x2i;

di = alpha1*alpha2*di;



f1i = valfunc1(c,fspace,s,[x2p,x1i],e,w);
f2i = valfunc1(c,fspace,s,[x2p,x2i],e,w);


f1inew=f1i;
f2inew=f2i;
x1inew=x1i;
x2inew=x2i;

while di>toli
   
 f1i=f1inew;
 f2i=f2inew;
 x1i=x1inew;
 x2i=x2inew;
    
  di = di*alpha2;
  x2inew=x1i.*(f2i<f1i)+(x2i+di).*(f2i>=f1i);
  f2inew=f1i.*(f2i<f1i)+valfunc1(c,fspace,s,[x2p,x2i+di],e,w).*(f2i>=f1i);
  
  x1inew=(x1i-di).*(f2i<f1i)+x2i.*(f2i>=f1i);
  f1inew=valfunc1(c,fspace,s,[x2p,x1i-di],e,w).*(f2i<f1i)+f2i.*(f2i>=f1i);
  
  end

  xi=x2inew.*(f2inew>=f1inew)+x1inew.*(f2inew<f1inew);

  f2p=valfunc1(c,fspace,s,[x2p,xi],e,w);

 f1pnew=f1p;
 f2pnew=f2p;
 x1pnew=x1p;
 x2pnew=x2p;

 
 while dp>tolp
     
     f1p=f1pnew;
     f2p=f2pnew;
     x1p=x1pnew;
     x2p=x2pnew;
     
     dp = dp*alpha2;
%     [x1p,x2p]
%      [f1p,f2p]
%      pause
     x2pnew=x1p.*(f2p<f1p)+(x2p+dp).*(f2p>=f1p);
     x1pnew=(x1p-dp).*(f2p<f1p)+x2p.*(f2p>=f1p);
    
 %compute f1pnew by setting xp=x1p-dp and searching over the xi that
 %maximizes the RHS of the bellman equation given xp
 
di  = bi-ai;
x1i = ai+alpha1*di;
x2i = ai+alpha2*di;

x1newi=x1i;
x2newi=x2i;

di = alpha1*alpha2*di;

f1i = valfunc1(c,fspace,s,[x1p-dp,x1i],e,w);
f2i = valfunc1(c,fspace,s,[x1p-dp,x2i],e,w);

f1inew=f1i;
f2inew=f2i;
x1inew=x1i;
x2inew=x2i;

while di>toli
   
 f1i=f1inew;
 f2i=f2inew;
 x1i=x1inew;
 x2i=x2inew;
    
  di = di*alpha2;
  x2inew=x1i.*(f2i<f1i)+(x2i+di).*(f2i>=f1i);
  f2inew=f1i.*(f2i<f1i)+valfunc1(c,fspace,s,[x1p-dp,x2i+di],e,w).*(f2i>=f1i);
  
  x1inew=(x1i-di).*(f2i<f1i)+x2i.*(f2i>=f1i);
  f1inew=valfunc1(c,fspace,s,[x1p-dp,x1i-di],e,w).*(f2i<f1i)+f2i.*(f2i>=f1i);
  
  end

  xi=x2inew.*(f2inew>=f1inew)+x1inew.*(f2inew<f1inew);
 
 f1pnew=valfunc1(c,fspace,s,[x1p-dp,xi],e,w).*(f2p<f1p)+f2p.*(f2p>=f1p);

 
 %compute f2pnew by setting xp=x2p+dp and searching over the xi that
 %maximizes the RHS of the bellman equation given xp

di  = bi-ai;
x1i = ai+alpha1*di;
x2i = ai+alpha2*di;

x1newi=x1i;
x2newi=x2i;

di = alpha1*alpha2*di;

f1i = valfunc1(c,fspace,s,[x2p+dp,x1i],e,w);
f2i = valfunc1(c,fspace,s,[x2p+dp,x2i],e,w);

f1inew=f1i;
f2inew=f2i;
x1inew=x1i;
x2inew=x2i;

while di>toli
   
 f1i=f1inew;
 f2i=f2inew;
 x1i=x1inew;
 x2i=x2inew;
    
  di = di*alpha2;
  x2inew=x1i.*(f2i<f1i)+(x2i+di).*(f2i>=f1i);
  f2inew=f1i.*(f2i<f1i)+valfunc1(c,fspace,s,[x2p+dp,x2i+di],e,w).*(f2i>=f1i);
  
  x1inew=(x1i-di).*(f2i<f1i)+x2i.*(f2i>=f1i);
  f1inew=valfunc1(c,fspace,s,[x2p+dp,x1i-di],e,w).*(f2i<f1i)+f2i.*(f2i>=f1i);
  
  end

  xi=x2inew.*(f2inew>=f1inew)+x1inew.*(f2inew<f1inew); 
  
 f2pnew=f1p.*(f2p<f1p)+valfunc1(c,fspace,s,[x2p+dp,xi],e,w).*(f2p>=f1p);
end

xp=x1pnew.*(f1pnew>f2pnew)+x2pnew.*(f1pnew<=f2pnew);

di  = bi-ai;
x1i = ai+alpha1*di;
x2i = ai+alpha2*di;

x1newi=x1i;
x2newi=x2i;

di = alpha1*alpha2*di;

f1i = valfunc1(c,fspace,s,[xp,x1i],e,w);
f2i = valfunc1(c,fspace,s,[xp,x2i],e,w);

f1inew=f1i;
f2inew=f2i;
x1inew=x1i;
x2inew=x2i;

while di>toli
   
 f1i=f1inew;
 f2i=f2inew;
 x1i=x1inew;
 x2i=x2inew;
    
  di = di*alpha2;
  x2inew=x1i.*(f2i<f1i)+(x2i+di).*(f2i>=f1i);
  f2inew=f1i.*(f2i<f1i)+valfunc1(c,fspace,s,[xp,x2i+di],e,w).*(f2i>=f1i);
  
  x1inew=(x1i-di).*(f2i<f1i)+x2i.*(f2i>=f1i);
  f1inew=valfunc1(c,fspace,s,[xp,x1i-di],e,w).*(f2i<f1i)+f2i.*(f2i>=f1i);
  
  end

  xi=x2inew.*(f2inew>=f1inew)+x1inew.*(f2inew<f1inew); 

  x=[xp,xi];