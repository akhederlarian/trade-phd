T=24;  % periods we wait for weights to converge

%generate grid of sbtates

sgrid=nodeunif(501,smin(1),smax(1));
edges=[sgrid(1);[sgrid(2:end)+sgrid(1:end-1)]/2];
K=511; 
demand=nodeunif(K,1e-7,1-1e-7);  %start with equidistributed sequence
demand=norminv(demand,0,sqrt(vbar));
demand=smax(2)*(demand>smax(2))+smin(2)*(demand<smin(2))+demand.*(demand>=smin(2)&demand<=smax(2));
edgesd=[demand(1:end-1)-sqrt(eps);demand(end)];

e=demand;
w=1/length(demand)*ones(size(demand));

state=gridmake(sgrid,e);

v=funeval(c_vx,fspace,state);


    v1=v(:,1);
    v2=v(:,2);
    x1=v(:,4:5);
    x2=v(:,6);
   
    psim=(x1(:,1).*(v1>=v2)+x2.*(v1<v2));
    isim=(x1(:,2).*(v1>=v2));
    stock=state(:,1);
    sales=min([exp(state(:,2)).*(psim./Pm).^(-gamma).*Pm.^(-theta).*Cm,stock],[],2);
    ssim=(1-delta)*(stock-sales+isim);  ssim=min(max(ssim,edges(1)+sqrt(eps)),edges(end)-sqrt(eps));

wz=1/length(sgrid)*ones(length(sgrid),1);  %guess weights on ewach of the points in sgrid


P=zeros(T,1);
Pa=P;
Fracorder=P;
Meanorder=P;
Imports=P;
Sales=P;
Inv=P;
IS=P;



for t=1:T
    
wnew=wz;
ww=gridmake(wnew,w); ww=ww(:,1).*ww(:,2);
  
 wjunk=hist2(ssim,state(:,2),edges,edgesd,ww);
 wz=sum(wjunk,2);
 
fprintf('%4i %6.2e %6.2e %6.2e\n',[t,norm(wz-wnew),mean(abs(wnew(wnew>1e-2|wz>1e-2)-wz(wnew>1e-2|wz>1e-2))./wz(wnew>1e-2|wz>1e-2)),...
    mean(abs(wnew(wnew>1e-4|wz>1e-4)-wz(wnew>1e-4|wz>1e-4))./wz(wnew>1e-4|wz>1e-4))]);

P(t)=(ww'*psim.^(1-gamma)).^(1/(1-gamma));
Fracorder(t)=ww'*(isim>1e-5);
Imports(t)=ww'*isim;

end

P=P(end-4:end);
Fracorder=Fracorder(end-4:end);
Imports=Imports(end-4:end);

save calm wz P Fracorder Imports 

start_crisis;

for month=1:1:size(Pguess,1);

    load calm 
    wzold=wz;
    
    Pm=Pguess(month);
    
    
sgrid=nodeunif(501,smin(1),smax(1));
edges=[sgrid(1);[sgrid(2:end)+sgrid(1:end-1)]/2];

K=511; 

demand=nodeunif(K,1e-7,1-1e-7);                 %   start with equidistributed sequence
demand=norminv(demand,0,sqrt(vbar));
demand=smax(2)*(demand>smax(2))+smin(2)*(demand<smin(2))+demand.*(demand>=smin(2)&demand<=smax(2));
edgesd=[demand(1:end-1)-sqrt(eps);demand(end)];

e=demand;
w=1/length(demand)*ones(size(demand));

state=gridmake(sgrid,e);

v=funeval(coeff(:,:,month),fspace,state);
    

    v1=v(:,1);
    v2=v(:,2);
    x1=v(:,4:5);
    x2=v(:,6);
   
    psim=(x1(:,1).*(v1>=v2)+x2.*(v1<v2));
    isim=(x1(:,2).*(v1>=v2));
    stock=state(:,1);
    sales=min([exp(state(:,2)).*(psim./Pm).^(-gamma).*Pm.^(-theta).*Cm,stock],[],2);
    ssim=(1-delta)*(stock-sales+isim); ssim=min(max(ssim,smin(1)),smax(1));
    
  wnew=wz;
  ww=gridmake(wnew,w); ww=ww(:,1).*ww(:,2);

   wjunk=hist2(ssim,state(:,2),edges,edgesd,ww);
   wz=sum(wjunk,2);

P_c=(ww'*psim.^(1-gamma)).^(1/(1-gamma));
Fracorder_c=ww'*(isim>1e-5);
Imports_c=ww'*isim;

P=[P;P_c];
Fracorder=[Fracorder;Fracorder_c];
Imports=[Imports;Imports_c];

save calm wz P Fracorder Imports; 

end



