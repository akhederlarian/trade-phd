T=500;
K=5000;
disp('simulating ...')
randn('state',0);

psim=zeros(T,K);
ssim=zeros(T,K);
isim=zeros(T,K);
sales=zeros(T,K);
shock=randn(T,K)*sqrt(vbar);


shock=smax(2)*(shock>smax(2))+smin(2)*(shock<smin(2))+shock.*(shock>=smin(2)&shock<=smax(2));

%load ergcalm;
%ergcalm=ergcalm2';
%c1=csave(:,:,1);
for t=1:T
   
    
    if t==1
        state=[nodeunif(K,smin(1),smax(1)),shock(1,:)'];  %give them enough not to adjust: twice their demand shock
        %state=[ergcalm.^scale,shock(1,:)'];
           
    else
        state=[(ssim(t-1,:)').^(scale),shock(t,:)'];
    end
    
    v=funeval(c1(:,4:5),fspace1,state);
    v1=v(:,1);
    v2=v(:,2);
    x=funeval(c1(:,1:3),fspace1,state);
    x1=x(:,1:2);
    x2=x(:,3);
   
    psim(t,:)=(x1(:,1).*(v1>=v2)+x2.*(v1<v2))';
    isim(t,:)=(x1(:,2).*(v1>=v2))';
    stock=state(:,1).^(1/scale);
    sales(t,:)=min([[exp(shock(t,:)).*(psim(t,:)./Pm).^(-gamma).*Cm]',stock],[],2)';
    
    ssim(t,:)=((1-delta)*(stock-sales(t,:)'+isim(t,:)'))';
    
end


statistics