% VALFUNC  Evaluates Bellman Optimand
  function [v,vx,vxx]=valfunc1(c,fspace,s,x,e,w);
  
global beta cucu delta smin smax theta gamma wss vbar f Pm Cm scale;
 
b=beta;
K = length(w);
ns=size(s,1);
 
      v = feval('menufun','f1',s,x,[],[]);
      for k=1:K
        kk = k + zeros(ns,1); 
        g = feval('menufun','g1',s,x,e(kk,:),w);
       
        v  = v  + b*w(k)*max(funeval(c,fspace,g),[],2);
     end