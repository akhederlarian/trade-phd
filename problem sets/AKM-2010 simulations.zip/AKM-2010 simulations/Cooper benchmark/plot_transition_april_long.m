clear;
clc;




mean_inv=[];
mean_Pm=[];
mean_isim_real=[];
mean_isim_nom=[];
mean_fraction=[];
omega=[];

load crashed;

mean_isim_real=[mean_isim_real;mean(isim(end-24:end,:)')'];
mean_isim_nom=[mean_isim_nom;mean(isim(end-24:end,:)')'.*wss];
mean_fraction=[mean_fraction;mean(isim(end-24:end,:)'>0)'];
mean_Pm=[mean_Pm;mean(psim(end-24:end,:)'.^(1-gamma))'.^(1/(1-gamma))];
omega=wss*ones(size(mean_Pm));

load transit_feedargentina;
Tbar=length(wsave);
wsave=wsave;
mean_isim_real=[mean_isim_real;mean(isim')'];
mean_isim_nom=[mean_isim_nom;mean(isim')'.*wsave'];
mean_fraction=[mean_fraction;mean(isim'>0)'];
mean_Pm=[mean_Pm;mean(psim'.^(1-gamma))'.^(1/(1-gamma))];
omega=[omega;wsave'];

figure(1)
plot((-24:1:Tbar)',log(omega/omega(25)),'r','linewidth',2);
hold on;
plot((-24:1:Tbar)',log(mean_Pm/mean_Pm(25)),'b--','linewidth',2);
legend('import price','consumer price index for imports')

figure(2)

plot((-24:1:Tbar)',mean_isim_real/mean_isim_real(25),'r','linewidth',2);
legend('real value of trade')
figure(3)

plot((-24:1:Tbar)',mean_fraction,'r','linewidth',2);
legend('fraction of importers')