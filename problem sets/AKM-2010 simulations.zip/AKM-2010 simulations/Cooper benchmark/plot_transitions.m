clear;
clc;
load frb_highdemand;

Pagg=mean(psim.^(1-theta),2).^(1/(1-theta));
inv=isim;

load frb_highdemand1

gamma=.79;
inv1=isim;
invplot=gamma*inv+(1-gamma)*isim;


Pagg1=mean(psim.^(1-theta),2).^(1/(1-theta));

Pplot=(gamma*Pagg.^(1-theta)+(1-gamma)*Pagg1.^(1-theta)).^(1/(1-theta));



load frb_highdemand_crisis

Paggcri=mean(psim.^(1-theta),2).^(1/(1-theta));
invcri=isim;

load frb_highdemand_crisis1

gamma=.79;
invcri1=isim;
invplotcri=gamma*invcri+(1-gamma)*isim;

Paggcri1=mean(psim.^(1-theta),2).^(1/(1-theta));

Pcriplot=(gamma*Paggcri.^(1-theta)+(1-gamma)*Paggcri1.^(1-theta)).^(1/(1-theta));
disp('done')

figure(1)
plot((-23:1:36)',[log(Pplot(end-23:end)/Pplot(end));log(Pcriplot(1:36)/Pplot(end))]);

title('Fig. 1: Aggregate price of imported goods')
xlabel('date after crisis')

hold on
plot((-23:1:36)',[zeros(24,1);log(3)*ones(36,1)],'r')

figure(2)

plot((-23:1:36)',[log(Pplot(end-23:end)/Pplot(end));log(Pcriplot(1:36)/Pplot(end))]);

title('Fig. 2: Price of high/low-fixed cost imports')
xlabel('date after crisis')

hold on
plot((-23:1:36)',[zeros(24,1);log(3)*ones(36,1)],'r')

plot((-23:1:36)',[log(Pagg(end-23:end)/Pagg(end));log(Paggcri(1:36)/Pagg(end))],'k')

plot((-23:1:36)',[log(Pagg1(end-23:end)/Pagg1(end));log(Paggcri1(1:36)/Pagg1(end))],'g')

figure(3)
title('Fig. 3: Fraction of goods with trade')

plot((-23:1:36)',[repmat(sum(invplot(end,:)'>0)/K,1,24),sum(invplotcri(1:36,:)'>0)/K]);

figure(4)
title('Fig. 4: Fraction high/low-fixed costs goods w/ trade');


hold on
plot((-23:1:36)',[repmat(sum(inv(end,:)'>0)/K,1,24),sum(invcri(1:36,:)'>0)/K],'r');

hold on
plot((-23:1:36)',[repmat(sum(inv1(end,:)'>0)/K,1,24),sum(invcri1(1:36,:)'>0)/K],'k');


figure(5)


clear psim, isim;
count0=sum(inv'>0);
count1=sum(inv1'>0);

count=gamma*count0+(1-gamma)*count1;
fract=(1-gamma)*count1./count;

count0=sum(invcri'>0);
count1=sum(invcri1'>0);

count=gamma*count0+(1-gamma)*count1;
fractcri=(1-gamma)*count1./count;

plot((-23:1:36)',[repmat(fract(end),1,24),fractcri(1:36)],'k');
title('Fig. 5: Fraction of high/low cost exporters')

figure(6)

plot((-23:1:36)',[repmat(sum(invplot(end,:)')/K,1,24),sum(invplotcri(1:36,:)')/K*3]);
hold on
plot((-23:1:36)',[ones(1,24),3^(-.5)*ones(1,36)],'r')
title('Export values')

figure(7)

plot((-23:1:36)',[repmat(sum(inv(end,:)')/K,1,24),sum(invcri(1:36,:)')/K*3],'r');
hold on

plot((-23:1:36)',[repmat(sum(inv1(end,:)')/K,1,24),sum(invcri1(1:36,:)')/K*3],'k');
title('Export values by type of firm')