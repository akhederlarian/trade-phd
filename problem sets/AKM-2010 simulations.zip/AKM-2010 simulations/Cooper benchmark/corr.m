% calculates corr between two variables
function corr=corr(x);
corr=corrcoef([x(:,1),x(:,2)]);
corr=corr(1,2);
