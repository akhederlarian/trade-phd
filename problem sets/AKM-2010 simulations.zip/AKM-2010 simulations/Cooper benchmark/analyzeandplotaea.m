clear;
clc;
load crashed;

inv=ssim(2:end,:)+sales(2:end,:)-ssim(1:end-1,:);
inv=[inv(1,:);inv];

ergcalm=ssim(end,:)';
save ergcalm ergcalm;
Pcalm=mean(psim(11:end,:)'.^(1-theta)).^(1/(1-theta));
Xcalm=mean(psim(11:end,:)'.*inv(11:end,:)');
Fcalm=mean(inv(11:end,:)'>.01);
save Pcalm Pcalm;
save Xcalm Xcalm;
save Fcalm Fcalm;


clear;
load cooper_crisis;
T=50;
K=100000;
randn('state',0);
psim=zeros(T,K);
ssim=zeros(T,K);
isim=zeros(T,K);
sales=zeros(T,K);
shock=randn(T,K)*sqrt(vbar);
shock=shock;
shock=smax(2)*(shock>smax(2))+smin(2)*(shock<smin(2))+shock.*(shock>=smin(2)&shock<=smax(2));

load ergcalm;
for t=1:T
    t
    if t==1
        state=[nodeunif(K,smin(1),smax(1)),shock(1,:)'];  %give them enough not to adjust: twice their demand shock
       state=[ergcalm.^scale,shock(1,:)'];
           
    else
        state=[(ssim(t-1,:)').^(scale),shock(t,:)'];
    end
    
    v=funeval(c1(:,4:5),fspace1,state);
    v1=v(:,1);
    v2=v(:,2);
    x=funeval(c1(:,1:3),fspace1,state);
    x1=x(:,1:2);
    x2=x(:,3);
   
    psim(t,:)=(x1(:,1).*(v1>=v2)+x2.*(v1<v2))';
    isim(t,:)=(x1(:,2).*(v1>=v2))';
    stock=state(:,1).^(1/scale);
    sales(t,:)=min([[exp(shock(t,:)).*(psim(t,:)./Pm).^(-theta).*Cm]',stock],[],2)';
    
    ssim(t,:)=(stock+isim(t,:)'-sales(t,:)')';
    
end

inv=ssim(2:end,:)+sales(2:end,:)-ssim(1:end-1,:);
load ergcalm;
inv=[ssim(1,:)+sales(1,:)-ergcalm',;inv];

Pcrisis=mean(psim'.^(1-theta)).^(1/(1-theta));
Xcrisis=mean(psim'.*inv');
Fcrisis=mean(inv'>.01);

disp('done')
