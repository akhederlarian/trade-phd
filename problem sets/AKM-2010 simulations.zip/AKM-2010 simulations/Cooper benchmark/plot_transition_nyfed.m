clear;
clc;

mean_inv=[];
mean_Pm=[];
mean_isim_real=[];
mean_isim_nom=[];
mean_fraction=[];
omega=[];

load crashed;


mean_isim_real=[mean_isim_real;mean(isim(end,:)')*ones(24,1)];
mean_isim_nom=[mean_isim_nom;mean(isim(end,:)')'.*wss*ones(24,1)];
mean_fraction=[mean_fraction;mean(isim(end,:)'>0)*ones(24,1)];
mean_Pm=[mean_Pm;mean(psim(end-1,:)'.^(1-gamma))'.^(1/(1-gamma))*ones(24,1)];


omega=wss*ones(size(mean_Pm));

load cooper_crisis;
wsave=(gamma-1)/gamma*1.5*ones(1,T);
mean_isim_real=[mean_isim_real;mean(isim')'];
mean_isim_nom=[mean_isim_nom;mean(isim')'.*wsave'];
mean_fraction=[mean_fraction;mean(isim'>0)'];
mean_Pm=[mean_Pm;mean(psim'.^(1-gamma))'.^(1/(1-gamma))];
omega=[omega;wsave'];


figure(4)
subplot(1,2,1);

plot((-23:1:T)',log(mean_isim_real/mean_isim_real(24)),'r','linewidth',2);
legend('import value')
axis([-18 18 -1 1])
axis 'auto y'
subplot(1,2,2);
plot((-23:1:T)',log(mean_fraction/mean_fraction(24)),'b--','linewidth',2);
legend('fraction of importers')
axis([-18 18 -1 1])
axis 'auto y'

figure(2)
plot((-23:1:T)',log(mean_Pm/mean_Pm(24)),'b')
hold on
plot((-23:1:T)',log(omega/omega(24)),'r')

