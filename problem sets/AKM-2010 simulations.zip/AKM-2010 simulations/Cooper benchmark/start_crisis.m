clear all;
clc;
%input parameters:

global beta cucu delta smin smax theta gamma wss vbar f Pm Cm scale itt;

%Parameters

%1: Preferences

beta=.94^(1/12);                 %discount factor
theta=1.5;                       %elasticity of substitution between H and F
gamma=1.5;                       %elasticity of substitution between different F


%2: Technology

delta=.025;                     %rate at which inventory in wharehouse depreciates
wss=(gamma-1)/gamma ;           %initial price of imports that importers face

%3: Uncertainty

vbar=1.1^2;                     %variance of Gaussian demand shocks

f=0.85;                          %fraction of revenue lost when importing
scale=1-1/gamma;                %use this scale factor to put more nodes in region where stuff is non-linear

Cm=1;                           %we call this f in the notes. 
Pm=1;                           %we call this p in the .tex notes.
                                %initial price of imports that importers face

%Now prepare functional approximation


k=51;
[e,w]=qnwnorm(k,0,vbar);
e=e(w>.01);
w=w(w>.01);
w=w/sum(w);





smin=0.01; 
smax=5;

smin=[smin.^scale,e(1)];                       
smax=[smax.^scale,e(end)];

n=[21,15];

fspace=fundefn('spli',n,smin,smax);
Phi=funbasx(fspace);                          %2 value functions

grid=funnode(fspace);                         
s=gridmake(grid);                             



reward=1/theta;
stock=s(:,1).^(1/scale);
va=wss*stock+exp(s(:,2))./theta+beta*reward/(1-beta);
c=funfitxy(fspace,Phi,[va,va]);
x=[ones(length(s),1),2*ones(length(s),1)];


for it=1:30
  cnew=vec(c);  
[bel, beljac] =solvebel(cnew,fspace,s,x,e,w);

c=cnew-(beljac\bel);

vold=funeval([cnew(1:prod(n),:),cnew(prod(n)+1:end,:)],fspace,s);
vnew=funeval([c(1:prod(n),:),c(prod(n)+1:end,:)],fspace,s);
vderold=funeval([cnew(1:prod(n),:),cnew(prod(n)+1:end,:)],fspace,s,[1 0]);
vdernew=funeval([c(1:prod(n),:),c(prod(n)+1:end,:)],fspace,s,[1 0]);

err=[(vold(:,2)-vold(:,1)-(vnew(:,2)-vnew(:,1)))];
fprintf('%4i %6.2e %6.2e\n',[it,norm(vderold-vdernew), norm(err)]);

if norm(vderold-vdernew)<1e-7&norm(err)<1e-7, break, end
end

[bel, beljac] =solvebel(c,fspace,s,x,e,w);
disp('Value function errors')
disp(norm(bel,inf))
if norm(bel,inf)>1e-5
    disp('Also use newton');
    optset('newton','showiters',1);
c=newton('solvebel',vec(c),fspace,s,x,e,w);
end
c=[c(1:prod(n)),c(prod(n)+1:end)];
cnew=c;

    


    
   



disp('Next retrieve optimal decision rules')
n1=[31,31];
fspace1=fundefn('lin',n1,smin,smax);
Phi1=funbasx(fspace1);                          %2 value functions

grid1=funnode(fspace1);                         
s1=gridmake(grid1);   
[v1,v2,x1,x2]=saveBelmax(cnew,fspace,s1,ones(prod(n1),1),e,w);
c1=funfitxy(fspace1,Phi1,[x1,x2,v1,v2]);
disp('done retrieving optimal stuff')
%break
simulate_transition