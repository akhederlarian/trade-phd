clear;
clc;
