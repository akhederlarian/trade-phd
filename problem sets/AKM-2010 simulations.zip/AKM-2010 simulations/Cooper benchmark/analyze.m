clear;
clc;
load joe;
inv=ssim(2:end,:)+sales(2:end,:)-ssim(1:end-1,:);

%compute hazard and histogram
vecstock=vec(ssim(101:end-1,:)-sales(102:end,:));
[f,xnode] = hist(vecstock,30);
xnode=nodeunif(30,0,max(vecstock));
%xnode(1)=0;
adj=vec(inv(101:end,:)>1e-2);
haz=zeros(length(xnode),1);
for  i=1:length(xnode)
    if i>1
    index=find(vecstock>=xnode(i-1)&vecstock<xnode(i));
else
    index=find(vecstock<xnode(i));
end

haz(i)=length(find(adj(index)==1))/length(index);

end
%break

close all;
figure(1)
subplot(2,1,1)
hist(vecstock,30);
hold on
plot(xnode,haz/10);

%compute a Herfhindhal index

inv=inv(end-95:end,:);

annualinv=zeros(12,size(inv,1)/12,K);
HH=zeros(size(inv,1)/12,K);
for i=1:K
annualinv(:,:,i)=reshape(inv(:,i),12,size(inv,1)/12);
HH(:,i)=sum((annualinv(:,:,i)./repmat(sum(annualinv(:,:,i)),12,1)).^2)';

end

sinv=-sort(-abs(annualinv),1);
%fraction accounted for by top month
f1=mean(mean(sum(sinv(1:1,:,:),1)./sum(sinv(:,:,:))));
f2=mean(mean(sum(sinv(1:2,:,:),1)./sum(sinv(:,:,:))));
f3=mean(mean(sum(sinv(1:3,:,:),1)./sum(sinv(:,:,:))));
f4=mean(mean(sum(sinv(1:4,:,:),1)./sum(sinv(:,:,:))));
f5=mean(mean(sum(sinv(1:5,:,:),1)./sum(sinv(:,:,:))));

HH(isnan(HH))=999;  %if no trade during that year
HH(isinf(HH))=999;
meanHH=mean(mean(HH(HH~=999))');
medianHH=median(mean(HH(HH~=999))');
fpos=median(mean(inv>0.1)');

fprintf('Mean Herfhindhal                      = %9.2f \n',meanHH);
fprintf('Median Herfhindhal                    = %9.2f \n',medianHH);
fprintf('Fraction with positive exports        = %9.2f \n',fpos);
fprintf('Fraction accounted by top 1 month     = %9.2f \n',f1);
fprintf('Fraction accounted by top 2 month     = %9.2f \n',f2);
fprintf('Fraction accounted by top 3 month     = %9.2f \n',f3);
fprintf('Fraction accounted by top 4 month     = %9.2f \n',f4);
fprintf('Fraction accounted by top 5 month     = %9.2f \n',f5);


