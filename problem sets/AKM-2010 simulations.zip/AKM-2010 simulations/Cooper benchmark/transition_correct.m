clear;
clc;
disp('simulating transition')
randn('state',0);

load benchmark_ergodic_crisis
save c1 c1 Cm fspace1;
clear;
load benchmark_ergodic_calm
clear c1 Cm fspace1;
load c1
Importsold=Imports;
Psimold=mean(sales.*psim)./mean(sales);
Fractionold=Fraction;

T=18;

Moments=zeros(T,9);
Psim=zeros(T,1);
Sales=zeros(T,1);
Imports=zeros(T,1);
Fraction=zeros(T,1);

for t=1:T
shock=demand(randperm(K)); 
    t
        state=[ssim.^(scale),shock];
    
    
    v=funeval(c1(:,4:5),fspace1,state);
    v1=v(:,1);
    v2=v(:,2);
    x=funeval(c1(:,1:3),fspace1,state);
    x1=x(:,1:2);
    x2=x(:,3);
   
    psim=(x1(:,1).*(v1>=v2)+x2.*(v1<v2));
    isim=(x1(:,2).*(v1>=v2));
    stock=state(:,1).^(1/scale);
    sales=min([exp(shock).*(psim./Pm).^(-gamma).*Cm,stock],[],2);
    
    ssim=(1-delta)*(stock-sales+isim);
    Moments(t,:)=[mean(ssim),var(ssim),skewness(ssim),kurtosis(ssim),prctile(ssim,10),prctile(ssim,25),prctile(ssim,50),prctile(ssim,75),prctile(ssim,90)];
    Psim(t)=mean(sales.*psim)./mean(sales);
    Sales(t)=mean(sales);
    Fraction(t)=mean(v1>=v2);
    Imports(t)=mean(isim);
end


if 1
    figure(2)
    plot((-(T-1):1:T)',[zeros(T,1);log(Psim/Psimold(end))]);
    hold on
    plot((-(T-1):1:T)',[zeros(T,1);log(1.5).*ones(T,1)],'r');
    figure(3)
    hold on
    subplot(1,2,1);
    plot((-(T-1):1:T)',[zeros(T,1);log(Imports/Importsold(end))],':');
    subplot(1,2,2);
    plot((-(T-1):1:T)',[zeros(T,1);log(Fraction/Fractionold(end))],'r:');
    
end