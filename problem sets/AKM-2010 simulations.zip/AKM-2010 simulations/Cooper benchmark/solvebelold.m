function [bel, beljac,x1] =solvebelold(c,fspace,s,x,e,w);

global beta cucu delta smin smax theta gamma wss vbar f Pm Cm scale;

c_in_or=[c(1:length(s)),c(length(s)+1:end)];
[v1,v2,x1,x2,v11,v12,v21,v22] = saveBelmaxold(c_in_or,fspace,s,x,e,w);


LHS=funeval(c_in_or,fspace,s);

B=funbas(fspace,s);

bel=zeros(2*length(s),1);
beljac=zeros(2*length(s),2*length(s));
bel(1:length(s))=LHS(:,1)-v1;
beljac(1:length(s),:)=[B,zeros(size(B))]-[v11,v12];
bel(length(s)+1:end)=LHS(:,2)-v2;
beljac(length(s)+1:end,:)=[zeros(size(B)),B]-[v21,v22];

