clear;
clc;
load crashed;
inv=ssim(2:end,:)/(1-delta)+sales(2:end,:)-ssim(1:end-1,:);

%compute hazard and histogram
normalize=mean(vec(sales(52:end,:)));
vecstock=vec(ssim(51:end-1,:))/normalize;  %normalize by mean sales
[f,xnode] = hist(vecstock,100);
xnode=nodeunif(50,0,max(vecstock));
%xnode(1)=0;
adj=vec(inv(51:end,:)>1e-2);
haz=zeros(length(xnode),1);
for  i=1:length(xnode)
    if i>1
    index=find(vecstock>=xnode(i-1)&vecstock<xnode(i));
else
    index=find(vecstock<xnode(i));
end

haz(i)=length(find(adj(index)==1))/length(index);

end

figure(1)
subplot(2,1,1)
hist(vecstock,30);
hold on
plot(xnode,haz/10);

load crisis_ergodic



inv=ssim(2:end,:)/(1-delta)+sales(2:end,:)-ssim(1:end-1,:);

%compute hazard and histogram
%normalize=mean(vec(sales(52:end,:)));
vecstock=vec(ssim(51:end-1,:))/normalize;  %normalize by mean sales
[f,xnode] = hist(vecstock,100);
xnode=nodeunif(50,0,max(vecstock));
%xnode(1)=0;
adj=vec(inv(51:end,:)>1e-2);
haz=zeros(length(xnode),1);
for  i=1:length(xnode)
    if i>1
    index=find(vecstock>=xnode(i-1)&vecstock<xnode(i));
else
    index=find(vecstock<xnode(i));
end

haz(i)=length(find(adj(index)==1))/length(index);

end

figure(1)
subplot(2,1,2)
hist(vecstock,30);
hold on
plot(xnode,haz/10);