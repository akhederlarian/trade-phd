function y=profit(x)

beta=.9992; 
theta=3;
w=(theta-1)/theta;
delta=.02;
vmin=0.5;
vmax=1.5;
s=0 ;

p=x(:,1);
i=x(:,2);

%p=x(1); i=x(1);
R=((s+i)./p.^(-theta)>=vmax).*p.^(-theta).*(vmin+vmax)/2; %unconstrained always
R=R+1/2/(vmax-vmin).*(-(s+i).^2.*p.^(theta)-vmin.^2.*p.^(-theta)+2*vmax*(s+i)).*(((s+i)./p.^(-theta)<vmax)&((s+i)./p.^(-theta)>vmin));
R=R+(s+i).*((s+i)./p.^(-theta)<=vmin); %always constrained

y=p.*R-beta*w*(1-delta)*R-w*(1-beta*(1-delta))*i;
