clear;
clc;




mean_inv=[];
mean_Pm=[];
mean_isim_real=[];
mean_isim_nom=[];
mean_fraction=[];
omega=[];

load crashed;

% mean_isim_real=[mean_isim_real;mean(isim(end-23:end,:)')'];
% mean_isim_nom=[mean_isim_nom;mean(isim(end-23:end,:)')'.*wss];
% mean_fraction=[mean_fraction;mean(isim(end-23:end,:)'>0)'];
% mean_Pm=[mean_Pm;mean(psim(end-23:end,:)'.^(1-gamma))'.^(1/(1-gamma))];


mean_isim_real=[mean_isim_real;mean(isim(end,:)')*ones(24,1)];
mean_isim_nom=[mean_isim_nom;mean(isim(end,:)')'.*wss*ones(24,1)];
mean_fraction=[mean_fraction;mean(isim(end,:)'>0)*ones(24,1)];
mean_Pm=[mean_Pm;mean(psim(end,:)'.^(1-gamma))'.^(1/(1-gamma))*ones(24,1)];


omega=wss*ones(size(mean_Pm));

load crisis1;
wsave=(gamma-1)/gamma/1.09*1.5*ones(1,T);
mean_isim_real=[mean_isim_real;mean(isim')'];
mean_isim_nom=[mean_isim_nom;mean(isim')'.*wsave'];
mean_fraction=[mean_fraction;mean(isim'>0)'];
mean_Pm=[mean_Pm;mean(psim'.^(1-gamma))'.^(1/(1-gamma))];
omega=[omega;wsave'];


figure(4)
subplot(1,2,1);

plot((-23:1:T)',log(mean_isim_real/mean_isim_real(24)),'r','linewidth',2);
legend('import value')
axis([-18 18 -1 1])
axis 'auto y'
subplot(1,2,2);
plot((-23:1:T)',log(mean_fraction/mean_fraction(24)),'b--','linewidth',2);
legend('fraction of importers')
axis([-18 18 -1 1])
axis 'auto y'
% subplot(1,3,3);
% hold on
% plot((-23:1:T)',log(mean_isim_real/mean_isim_real(24)),'r','linewidth',2);
% plot((-23:1:T)',log(mean_fraction/mean_fraction(24)),'b--','linewidth',2);
% counterfactual=mean_isim_real./mean_fraction/mean_isim_real(24)*mean_fraction(24);
% plot((-23:1:T)',log(counterfactual),'k:','linewidth',2);
% axis([-18 18 -1 1])
% axis 'auto y'
% legend('import value','fraction of importers','imports per importer')
