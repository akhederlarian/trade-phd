T=24;  % periods we wait for weights to converge

%generate grid of sbtates

sgrid=nodeunif(501,smin(1),smax(1));
edges=[sgrid(1);[sgrid(2:end)+sgrid(1:end-1)]/2];
K=511; 
demand=nodeunif(K,1e-7,1-1e-7);  %start with equidistributed sequence
demand=norminv(demand,0,sqrt(vbar));
demand=smax(2)*(demand>smax(2))+smin(2)*(demand<smin(2))+demand.*(demand>=smin(2)&demand<=smax(2));
edgesd=[demand(1:end-1)-sqrt(eps);demand(end)];

e=demand;
w=1/length(demand)*ones(size(demand));

state=gridmake(sgrid,e);

v=funeval(c_vx,fspace,state);
    
    v1=v(:,1);
    v2=v(:,2);
    x1=v(:,3:4);
    x2=v(:,5);
   
    psim=(x1(:,1).*(v1>=v2)+x2.*(v1<v2));
    isim=(x1(:,2).*(v1>=v2));
    stock=state(:,1);
    sales=min([exp(state(:,2)).*(psim./Pm).^(-gamma).*Cm,stock],[],2);
    ssim=(1-delta)*(stock-sales+isim);

wz=1/length(sgrid)*ones(length(sgrid),1);  %guess weights on ewach of the points in sgrid


P=zeros(T,1);
Pa=P;
Fracorder=P;
Meanorder=P;
Imports=P;
Sales=P;
Inv=P;
IS=P;



for t=1:T
    
  wnew=wz;
  ww=gridmake(wnew,w); ww=ww(:,1).*ww(:,2);


  
 wjunk=hist2(ssim,state(:,2),edges,edgesd,ww);
 wz=sum(wjunk,2);
 
  
fprintf('%4i %6.2e %6.2e %6.2e\n',[t,norm(wz-wnew),mean(abs(wnew(wnew>1e-2|wz>1e-2)-wz(wnew>1e-2|wz>1e-2))./wz(wnew>1e-2|wz>1e-2)),...
    mean(abs(wnew(wnew>1e-4|wz>1e-4)-wz(wnew>1e-4|wz>1e-4))./wz(wnew>1e-4|wz>1e-4))]);


P(t)=(ww'*psim.^(1-gamma)).^(1/(1-gamma));
Pa(t)=ww'*psim;
Fracorder(t)=ww'*(isim>1e-5);
Imports(t)=ww'*isim;
Meanorder(t)=Imports(t)/Fracorder(t);
Sales(t)=ww'*sales;
Inv(t)=ww'*ssim;

if t==T
low=stock<ww'*stock;
Plow=(ww(low)'/sum(ww(low))*psim(low).^(1-gamma)).^(1/(1-gamma));
Phi=(ww(~low)'/sum(ww(~low))*psim(~low).^(1-gamma)).^(1/(1-gamma));
Implow=ww(low)'/sum(ww(low))*isim(low);
Imphi=ww(~low)'/sum(ww(~low))*isim(~low);
Fralow=ww(low)'/sum(ww(low))*(isim(low)>1e-5);
Frahi=ww(~low)'/sum(ww(~low))*(isim(~low)>1e-5);

end

end

save calm wz P Fracorder Imports Meanorder Sales Inv Pa Plow Phi Implow Imphi Fralow Frahi low


start_crisis;
load calm
wzold=wz;

T=18;  %periods we wait for weights to converge

%generate grid of sbtates

sgrid=nodeunif(501,smin(1),smax(1));
edges=[sgrid(1);[sgrid(2:end)+sgrid(1:end-1)]/2];
K=511; 
demand=nodeunif(K,1e-7,1-1e-7);  %start with equidistributed sequence
demand=norminv(demand,0,sqrt(vbar));
demand=smax(2)*(demand>smax(2))+smin(2)*(demand<smin(2))+demand.*(demand>=smin(2)&demand<=smax(2));
edgesd=[demand(1:end-1)-sqrt(eps);demand(end)];

e=demand;
w=1/length(demand)*ones(size(demand));

state=gridmake(sgrid,e);

v=funeval(c_vx,fspace,state);
    
    v1=v(:,1);
    v2=v(:,2);
    x1=v(:,3:4);
    x2=v(:,5);
   
    psim=(x1(:,1).*(v1>=v2)+x2.*(v1<v2));
    isim=(x1(:,2).*(v1>=v2));
    stock=state(:,1);
    sales=min([exp(state(:,2)).*(psim./Pm).^(-gamma).*Cm,stock],[],2);
    ssim=(1-delta)*(stock-sales+isim);



P_c=zeros(T,1);
Pa_c=P_c;
Fracorder_c=P_c;
Meanorder_c=P_c;
Imports_c=P_c;
Sales_c=P_c;
Inv_c=P_c;
IS_c=P_c;

Plow_c=zeros(T,1);
Phi_c=zeros(T,1);
Implow_c=zeros(T,1);
Imphi_c=zeros(T,1);
Fralow_c=zeros(T,1);
Frahi_c=zeros(T,1);

for t=1:T
    
  wnew=wz;
  ww=gridmake(wnew,w); ww=ww(:,1).*ww(:,2);

 wjunk=hist2(ssim,state(:,2),edges,edgesd,ww);
 wz=sum(wjunk,2);
 
 

fprintf('%4i %6.2e %6.2e %6.2e\n',[t,norm(wz-wnew),mean(abs(wnew(wnew>1e-2|wz>1e-2)-wz(wnew>1e-2|wz>1e-2))./wz(wnew>1e-2|wz>1e-2)),...
    mean(abs(wnew(wnew>1e-4|wz>1e-4)-wz(wnew>1e-4|wz>1e-4))./wz(wnew>1e-4|wz>1e-4))]);


P_c(t)=(ww'*psim.^(1-gamma)).^(1/(1-gamma));
Pa_c(t)=ww'*psim;
Fracorder_c(t)=ww'*(isim>1e-5);
Imports_c(t)=ww'*isim;
Meanorder_c(t)=Imports_c(t)/Fracorder_c(t);
Sales_c(t)=ww'*sales;
Inv_c(t)=ww'*ssim;

Plow_c(t)=(ww(low)'/sum(ww(low))*psim(low).^(1-gamma)).^(1/(1-gamma));
Phi_c(t)=(ww(~low)'/sum(ww(~low))*psim(~low).^(1-gamma)).^(1/(1-gamma));
Implow_c(t)=ww(low)'/sum(ww(low))*isim(low);
Imphi_c(t)=ww(~low)'/sum(ww(~low))*isim(~low);
Fralow_c(t)=ww(low)'/sum(ww(low))*(isim(low)>1e-5);
Frahi_c(t)=ww(~low)'/sum(ww(~low))*(isim(~low)>1e-5);


end

%clear psim x1 x2 ww v v1 v2 v3 isim sales stock state ssim
subplot(1,3,1);
hold on
plot([0*P(end-4:end);0*P_c(1:15)+deval],'r');
hold on
plot(log([P(end-4:end)/P(end);P_c(1:15)/P(end)]))
title('Price index, log')
subplot(1,3,2)
hold on
plot(log([Imports(end-4:end)/Imports(end);Imports_c(1:15)/Imports(end)]));
title('Imports, log')
subplot(1,3,3)
hold on
plot(log([Fracorder(end-4:end)/Fracorder(end);Fracorder_c(1:15)/Fracorder(end)]));
title('Fraction firms importing, log')