function out1 = menufun(flag,s,e)

global gamma wss Pm Cm;


v=exp(s);        %demand

switch flag


case 'f'; % REWARD FUNCTION   %firms maximize nominal profits

    p=gamma/(gamma-1)*wss;
    q=v.*(p./Pm).^(-gamma).*Cm;

    out1 = (p-wss).*q;

case 'g'
out1=e;

end