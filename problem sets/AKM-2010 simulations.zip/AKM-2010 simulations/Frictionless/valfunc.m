% VALFUNC  Evaluates Bellman Optimand
  function v = valfunc(c,fspace,s,e,w)
  
  global beta

K  = length(w);
ns = size(s,1);


     v = feval('menufun','f',s,e);
   
      for k=1:K
          
        kk = k + zeros(ns,1); 
     
        g = feval('menufun','g',s,e(kk,:));
        v  = v  + beta*w(k).*funeval(c,fspace,g); 
      end