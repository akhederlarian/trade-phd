clear all;
clc;
%input parameters:

global beta gamma wss Pm Cm;

%Parameters

%1: Preferences

beta=.94^(1/12);                
gamma=1.5;       
tau=1+.10*0;
wss=(gamma-1)/gamma;           
wss=wss*tau;

vbar=1.15^2;                    

Cm=1;                           
Pm=1;                           

%express menu cost in terms of SS revenue
p=gamma/(gamma-1)*wss;

%Discretize random variables

k=51;
[e,w]=qnwnorm(k,0,vbar);
w=w(e<norminv(.999,0,sqrt(vbar))&e>norminv(.001,0,sqrt(vbar)));
e=e(e<norminv(.999,0,sqrt(vbar))&e>norminv(.001,0,sqrt(vbar)));
w=w/sum(w);

%Bounds for state-space

smin=e(1);                       
smax=e(end);

%Approximation family:
n=35;

fspace=fundef({'spli',nodeunif(n,smin,smax),0,3});

Phi=funbasx(fspace);                          %2 value functions
grid=funnode(fspace);                         
s=gridmake(grid);                             

%Guess value function and decision rules:

v=exp(s).*(p.^(1-gamma)-wss.*p.^(-gamma));
c=funfitxy(fspace,Phi,v);
ns=length(s);

%Few rounds of function iteration using golden search

load c

for it=1:3000
 
cold=c;
v = valfunc(c,fspace,s,e,w);
c=funfitxy(fspace,s,v);
fprintf('%4i %6.2e\n',[it,norm(c-cold)]);

if norm(c-cold)<1e-5, break, end
end
    
EV=w'*funeval(c,fspace,e)
save c c