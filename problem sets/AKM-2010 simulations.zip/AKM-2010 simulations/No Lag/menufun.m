function [out1,out2] = menufun(flag,s,x,e,w)

global delta smin smax gamma wss f Pm Cm;

n=size(s,1);

v=exp(s(:,2));        %demand
stock=s(:,1);         %stock of inventory on hand
w=wss;

switch flag

case 'bp'  % bound for first control
 
  out1 =.1*ones(n,1);  
  out2 =50*ones(n,1);

case 'bi'  % bound for second control

  out1 =max([smin(1)*ones(n,1)-(max([stock-v,zeros(n,1)],[],2)),zeros(n,1)],[],2);  
  out2 =max([smax(1)*ones(n,1)-(max([stock-v,zeros(n,1)],[],2)),zeros(n,1)],[],2);

case 'f1'; % REWARD FUNCTION   %firms maximize nominal profits
p=x(:,1);
i=x(:,2);
q=v.*min([(p./Pm).^(-gamma).*Cm,(stock+i)./v],[],2);

    out1 =p.*q-w.*i-f;

case 'f2'
p=x(:,1);
q=min([v.*(p./Pm).^(-gamma).*Cm,stock],[],2);

    out1 =p.*q;
        
case 'g1'; % STATE TRANSITION FUNCTION
p=x(:,1);
i=x(:,2);
q=min([v.*(p./Pm).^(-gamma).*Cm,stock+i],[],2);

out1=[(1-delta)*(stock-q+i),s(:,2)];

case 'g2'
p=x(:,1);
q=min([v.*(p./Pm).^(-gamma).*Cm,stock],[],2);

out1=[(1-delta)*(stock-q),s(:,2)];

case 'g3'
out1=[s(:,1),e];

end