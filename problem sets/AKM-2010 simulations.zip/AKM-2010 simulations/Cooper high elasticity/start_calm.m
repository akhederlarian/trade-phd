clear all;
clc;
%input parameters:

global beta cucu delta smin smax theta gamma wss vbar f Pm Cm scale itt xguess;

%Parameters

%1: Preferences

beta=.94^(1/12);                %discount factor
theta=1.5;                      %elasticity of substitution between H and F
gamma=4;                        %elasticity of substitution between different F

%2: Technology

delta=.025;                     %rate at which inventory in wharehouse depreciates
wss=(gamma-1)/gamma;            %initial price of imports that importers face

%3: Uncertainty

vbar=1.8^2;                     %variance of Gaussian demand shocks

%4: Adjustment cost

f=0.55;                         %fraction of revenue lost when importing
scale=1-1/gamma;                %use this scale factor to put more nodes in region where stuff is non-linear



Pm=1.1463;                        %we call this p in the .tex notes.
                                %initial price of imports that importers face
                                
                           
Cm=Pm.^(-theta);          

%we call this f in the notes. 
crisis=1;
simul=0;
erg=0;
plotergodic=0;
plottransition=1;

trans=0;

if crisis
wss=wss*1.5;
Pm=1.7104;                            
Cm=Pm.^(-theta);
%beta=.70^(1/12);
%Cm=.85;
end
                                
                                
                                
%Now prepare functional approximation


%Discretize random variables

k=15;
[e,w]=qnwnorm(k,0,vbar);
w=w(e<norminv(.99,0,sqrt(vbar))&e>norminv(.01,0,sqrt(vbar)));
e=e(e<norminv(.99,0,sqrt(vbar))&e>norminv(.01,0,sqrt(vbar)));
w=w/sum(w);


%Bounds for state-space
smin=0.01; 
smax=18;
smin=[smin.^scale,e(1)];                       
smax=[smax.^scale,e(end)];


%Approximation family:
n=[15,15];
fspace=fundefn('spli',n,smin,smax);
Phi=funbasx(fspace);                          %2 value functions
grid=funnode(fspace);                         
s=gridmake(grid);                             


%Guess value function and decision rules:
reward=1/theta;
stock=s(:,1).^(1/scale);
va=wss*stock+exp(s(:,2))./theta+beta*reward/(1-beta);
c=funfitxy(fspace,Phi,[va,va]);
x=[ones(length(s),1)*1.5,3*ones(length(s),1)];
xguess=x;


%load c_small

%Few rounds of function iteration using golden search
for it=1:5
    cnew=c;
[v1,v2,x] = saveBelmaxold(c,fspace,s,x,e,w);
c=funfitxy(fspace,s,[v1,v2]);
vold=funeval(cnew,fspace,s);
vnew=funeval(c,fspace,s);
vderold=funeval(cnew,fspace,s,[1 0]);
vdernew=funeval(c,fspace,s,[1 0]);

err=[(vold(:,2)-vold(:,1)-(vnew(:,2)-vnew(:,1)))];
fprintf('%4i %6.2e %6.2e\n',[it,norm(vderold-vdernew), norm(err)]);

if norm(vderold-vdernew)<1e-7&norm(err)<1e-7, break, end
end
    
xguess=x;

%Few rounds of Newton using golden search
for it=1:30
  cnew=vec(c);  
[bel, beljac,x] =solvebelold(cnew,fspace,s,x,e,w);

c=cnew-(beljac\bel);

vold=funeval([cnew(1:prod(n),:),cnew(prod(n)+1:end,:)],fspace,s);
vnew=funeval([c(1:prod(n),:),c(prod(n)+1:end,:)],fspace,s);
vderold=funeval([cnew(1:prod(n),:),cnew(prod(n)+1:end,:)],fspace,s,[1 0]);
vdernew=funeval([c(1:prod(n),:),c(prod(n)+1:end,:)],fspace,s,[1 0]);

err=[(vold(:,2)-vold(:,1)-(vnew(:,2)-vnew(:,1)))];
fprintf('%4i %6.2e %6.2e\n',[it,norm(vderold-vdernew), norm(err)]);

if norm(vderold-vdernew)<1e-7&norm(err)<1e-7, break, end
end


xguess=x;

% %Few rounds of Newton using Nelder-Mead for decision rules
% for it=1:30
%   cnew=vec(c);  
% [bel, beljac,x] =solvebel(cnew,fspace,s,x,e,w);
% 
% c=cnew-(beljac\bel);
% 
% vold=funeval([cnew(1:prod(n),:),cnew(prod(n)+1:end,:)],fspace,s);
% vnew=funeval([c(1:prod(n),:),c(prod(n)+1:end,:)],fspace,s);
% vderold=funeval([cnew(1:prod(n),:),cnew(prod(n)+1:end,:)],fspace,s,[1 0]);
% vdernew=funeval([c(1:prod(n),:),c(prod(n)+1:end,:)],fspace,s,[1 0]);
% 
% err=[(vold(:,2)-vold(:,1)-(vnew(:,2)-vnew(:,1)))];
% fprintf('%4i %6.2e %6.2e\n',[it,norm(vderold-vdernew), norm(err)]);
% 
% if norm(vderold-vdernew)<1e-7&norm(err)<1e-7, break, end
% end

%Check convergence formally, not in c, but also in f
[bel, beljac,x] =solvebelold(c,fspace,s,x,e,w);
disp('Value function errors')
disp(norm(bel,inf))
if norm(bel,inf)>1e-5
    disp('Also use newton');
    optset('newton','showiters',1);
c=newton('solvebelold',vec(c),fspace,s,x,e,w);
end
c=[c(1:prod(n)),c(prod(n)+1:end)];
cnew=c;

    
disp('Next retrieve optimal decision rules')

%Use old to come up with new guess

n1=[35,35];
fspace1=fundefn('lin',n1,smin,smax);
Phi1=funbasx(fspace1);                          %2 value functions
grid1=funnode(fspace1);                         
s1=gridmake(grid1);   
tic
[v1,v2,x1,x2]=saveBelmaxold(cnew,fspace,s1,ones(prod(n1),1),e,w);
xguess=x1;
toc
% tic
% [v1,v2,x1,x2]=saveBelmax(cnew,fspace,s1,xguess,e,w);
% toc
c1=funfitxy(fspace1,Phi1,[x1,x2,v1,v2]);
disp('done retrieving optimal stuff')


if simul==1
simulate
end

if erg==1
    ergodic
end