clear all;
clc;
%input parameters:

global beta cucu delta smin smax theta gamma wss vbar f Pm Cm scale itt xguess;

%Parameters

%1: Preferences

beta=.94^(1/12);                %discount factor
theta=1.5;                      %elasticity of substitution between H and F
gamma=4;                        %elasticity of substitution between different F

%2: Technology

delta=.025;                     %rate at which inventory in wharehouse depreciates
wss=(gamma-1)/gamma;            %initial price of imports that importers face

%3: Uncertainty

vbar=1.8^2;                     %variance of Gaussian demand shocks

%4: Adjustment cost

f=0.55;                         %fraction of revenue lost when importing
scale=1-1/gamma;                %use this scale factor to put more nodes in region where stuff is non-linear


wss=wss*1.5;
                                
%Now prepare functional approximation


%Discretize random variables

k=15;
[e,w]=qnwnorm(k,0,vbar);
w=w(e<norminv(.99,0,sqrt(vbar))&e>norminv(.01,0,sqrt(vbar)));
e=e(e<norminv(.99,0,sqrt(vbar))&e>norminv(.01,0,sqrt(vbar)));
w=w/sum(w);


%Bounds for state-space
smin=0.01; 
smax=18;
smin=[smin.^scale,e(1)];                       
smax=[smax.^scale,e(end)];


%Approximation family:
n=[15,15];
fspace=fundefn('spli',n,smin,smax);
Phi=funbasx(fspace);                          %2 value functions
grid=funnode(fspace);                         
s=gridmake(grid);                             


%Guess value function and decision rules:
reward=1/theta;
stock=s(:,1).^(1/scale);
va=wss*stock+exp(s(:,2))./theta+beta*reward/(1-beta);
c=funfitxy(fspace,Phi,[va,va]);
x=[ones(length(s),1)*1.5,3*ones(length(s),1)];
xguess=x;


load c_crisis;
load Psim;
Tsim=18;
csave=zeros(prod(n),5,Tsim);
for it=Tsim:-1:1
    if it==Tsim
    c=c_crisis;    
    else
    c=csave(:,4:5,it+1);    
    end
    
Pm=Psim(it);
Cm=Pm.^(-theta);
disp([it,Pm,Cm]);
[v1,v2,x1,x2] = saveBelmaxold(c,fspace,s,x,e,w);
csave(:,:,it)=funfitxy(fspace,s,[x1,x2,v1,v2]);
end