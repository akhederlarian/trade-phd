T=15;
K=300000;
clc;
disp('simulating ergodic distribution...')
randn('state',0);


%load ergcalm;
%ergcalm=ergcalm2';
%c1=csave(:,:,1);
demand=nodeunif(K,1e-7,1-1e-7);  %start with equidistributed sequence
demand=norminv(demand,0,sqrt(vbar));
demand=smax(2)*(demand>smax(2))+smin(2)*(demand<smin(2))+demand.*(demand>=smin(2)&demand<=smax(2));



ssim=nodeunif(K,smin(1),smax(1)).^(1/scale);

Moments=zeros(T,9);
Psim=zeros(T,1);
Sales=zeros(T,1);
Imports=zeros(T,1);
Fraction=zeros(T,1);

for t=1:T
shock=demand(randperm(K)); 
    t
        state=[ssim.^(scale),shock];
    
    
    v=funeval(c1(:,4:5),fspace1,state);
    v1=v(:,1);
    v2=v(:,2);
    x=funeval(c1(:,1:3),fspace1,state);
    x1=x(:,1:2);
    x2=x(:,3);
   
    psim=(x1(:,1).*(v1>=v2)+x2.*(v1<v2));
    isim=(x1(:,2).*(v1>=v2));
    stock=state(:,1).^(1/scale);
    sales=min([exp(shock).*(psim./Pm).^(-gamma).*Cm,stock],[],2);
    
    ssim=(1-delta)*(stock-sales+isim);
    Moments(t,:)=[mean(ssim),var(ssim),skewness(ssim),kurtosis(ssim),prctile(ssim,10),prctile(ssim,25),prctile(ssim,50),prctile(ssim,75),prctile(ssim,90)];
    Psim(t)=mean(psim.^(1-gamma)).^(1/(1-gamma));
    Sales(t)=mean(sales);
    Fraction(t)=mean(v1>=v2&isim>0.01);
    Imports(t)=mean(isim);
end

stock=stock/1.3084;    %normalize by mean sales

if plotergodic
    figure(1)
    subplot(2,1,crisis+1)
    hist(stock,25);
    hold on
    xnode=nodeunif(25,min(stock),max(stock));

adj=isim>0;
haz=zeros(length(xnode)-1,1);
for i=2:length(xnode)
    index=find(stock>=xnode(i-1)&stock<xnode(i));
    haz(i-1)=length(find(adj(index)==1))/length(index);
end
plot(xnode(2:end),haz/4,'r')
end