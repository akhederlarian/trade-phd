function [v1,v2,xadjust,xnadjust,v11,v12,v21,v22] = saveBelmax(c,fspace,s,x,e,w);

global beta cucu delta smin smax theta gamma wss vbar f Pm Cm scale xguess;

b=beta;

solveboth;
err=mean(mean(abs(x-xguess)))
xguess=x;
it=1;
while err>.001&length(find(abs(x(:,1)-xguess(:,1))>1e-4|abs(x(:,2)-xguess(:,2))>1e-4))>0
    
    solveboth;
    err=norm(x-xguess);
    disp([it,err,length(find(abs(x(:,1)-xguess(:,1))>1e-4|abs(x(:,2)-xguess(:,2))>1e-4))])
    it=it+1;
   
   xguess=x;
    
end

xadjust=x;
v1=valfunc1(c,fspace,s,xadjust,e,w);

solve2;
xnadjust=x;
v2=valfunc2(c,fspace,s,xnadjust,e,w);

ns=length(s);
if nargout>4
      v11 = zeros(ns,ns);
      v12= zeros(ns,ns);
      v21=zeros(ns,ns);
      v22=zeros(ns,ns);
      
      for k=1:length(w)           %go over all possible values e (discretized distribution of disturbances) can take
        kk = k+zeros(ns,1);
        g = feval('menufun','g1',s,xadjust,e(kk,:),w);
        vadj=fund(c(:,1),fspace,g,1);                                                 %check which one is higher
        vnadj=fund(c(:,2),fspace,g,1);
      
       v11 = v11 + b*w(k).*(funbas(fspace,g).*repmat([vadj>=vnadj],1,ns));          %with respect to cadj
       v12= v12+ b*w(k).*(funbas(fspace,g).*repmat([vadj<vnadj],1,ns));           %with respect to cnadj
      
       gnadj=feval('menufun','g2',s,xnadjust,e(kk,:),w);
       
       vadj=fund(c(:,1),fspace,gnadj,1);                                              %check which one is higher
       vnadj=fund(c(:,2),fspace,gnadj,1);
        
       
       v21 = v21 + b*w(k).*(funbas(fspace,gnadj).*repmat([vadj>=vnadj],1,ns));    %with respect to cadj
       v22= v22+ b*w(k).*(funbas(fspace,gnadj).*repmat([vadj<vnadj],1,ns));     %with respect to cnadj
   end
end