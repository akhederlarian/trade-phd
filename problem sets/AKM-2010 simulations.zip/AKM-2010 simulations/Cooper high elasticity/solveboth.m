
[ap,bp]=feval('menufun','bp',s,x,[],[]);
[ai,bi]=feval('menufun','bi',s,x,[],[]);
x_init=xguess;
x_min=[ap,ai];
x_max=[bp,bi];

 tol_x    = 1e-6;         % tolerance for convergence in x
 tol_f    = 1e-7;         % tolerance for convergence in f
 max_iter = 200;         % maximum number of function evaluations
 
N = size(x_init,1);
n = size(x_init,2);

onesn = ones(N,n); 
ot = repmat(2:n+1,N,1);
on = repmat(1:n,N,1);

% Nelder-Mead constants
a_reflect = 2;  a_expand = 1;  a_contract = 0.5; a_shrink = 0.5;

% Evaluate the initial guess and the range of allowable parameter variation

for i=1:n
x_init(:,i) = min([max([x_init(:,i),x_min(:,i)],[],2),x_max(:,i)],[],2);
end
fv = -valfunc1(c,fspace,s,[x_init],e,w);

   
% Place input guess in the simplex! (credit L.Pfeffer at Stanford)
% Set up a simplex near the initial guess.
delta_x=0*x_init;
for i=1:n
delta_x(:,i) = min([0.2*(1+abs(x_init(:,i))) , 0.1*(x_max(:,i)-x_init(:,i)).*(x_max(:,i)~=x_init(:,i))],[],2);
delta_x(delta_x(:,i) == 0,i) = -0.1*(x_init(delta_x(:,i) == 0,i)-x_min(delta_x(:,i) == 0,i));
end


% --- initialization

simplex = zeros(N,n,n+1);         % last dimension over vertices of simplex 
simplex(:,:,1)=x_init;
fsimplex=zeros(N,n+1);            % function at each n+1 nodes in simplex
fsimplex(:,1)=fv;

for j = 1:n
    y = x_init;
    y(:,j) = y(:,j) + delta_x(:,j);
    
    for i=1:n
    x(:,i) = min([max([y(:,i),x_min(:,i)],[],2),x_max(:,i)],[],2);
    end
    
    simplex(:,:,j+1) = x;     %create simplex one by one
    fsimplex(:,j+1) = -valfunc1(c,fspace,s,[x],e,w);

end


% order the vertices in increasing order of fv
[fv,idx] = sort(fsimplex,2);   %idx has, for each state s=1..N, the 3rd dimension of simplex that is lowest, second lowest, ... highest
simplexjunk=zeros(size(simplex));
for i=1:n+1   %over lowest, second lowest, ... highest
   for j=1:n+1 %over current 3rd dimension of simplex
simplexjunk(idx(:,i)==j,:,i) = simplex(idx(:,i)==j,:,j);
end
end
simplex=simplexjunk;
clear simplexjunk;


iter=1;
while iter < max_iter         

    change_x = norm(vec(repmat(simplex(:,:,1),[1,1,n])-simplex(:,:,2:n+1)));         %change in x
    change_f = norm(repmat(fv(:,1),1,n)-fv(:,2:n+1));                                %improvement in f

    if change_x < tol_x & change_f < tol_f
            break;
    end

% One step of the Nelder-Mead simplex algorithm

% reflect

    midpoint=zeros(N,n);                    % centroid of better vertices
    for i=1:n
        midpoint=midpoint+simplex(:,:,i)/n;      %average dimension of each simplex
    end
    
    vr=midpoint+a_reflect*(midpoint-simplex(:,:,n+1));
    
   for i=1:n
     vr(:,i) = min([max([vr(:,i),x_min(:,i)],[],2),x_max(:,i)],[],2);
    end

   

    fr = -valfunc1(c,fspace,s,vr,e,w);     %compute function under reflection
    
    fk=fr;                                 %function at new point in simplex
    vk=vr;                                 %new point in simplex

     happy=fr < fv(:,n+1);                 %all these guys will be replaced with reflection or expansion

%expand     
     
expand=(fr<fv(:,1));                       %reflection better than all points in simplex
 
if any(expand==1)
     ve=midpoint+a_expand*(vr-midpoint);
    
   for i=1:n
     ve(:,i) = min([max([ve(:,i),x_min(:,i)],[],2),x_max(:,i)],[],2);
   end
junk=zeros(N,1);
junk(expand==1) = -valfunc1(c,fspace,s(expand==1,:),vr(expand==1,:),e,w);     %only do for relevant guys
if any(junk(expand==1)<fr(expand==1))
vk(expand==1&junk<fr,:)=ve(expand==1&junk<fr,:); %replace point with ve if function better than expansion
fk(expand==1&junk<fr)=junk(junk<fr);
end
end    

%contract

contract=(fr>=fv(:,n+1));            %reflection fails to find a point better (i.e., smaller) than worst
if any(contract==1)
    vc=midpoint+a_contract*(midpoint-simplex(:,:,n+1));
     for i=1:n
     vc(:,i) = min([max([vc(:,i),x_min(:,i)],[],2),x_max(:,i)],[],2);
    
   end
   junk=zeros(N,1);
   junk(contract==1) = -valfunc1(c,fspace,s(contract==1,:),vc(contract==1,:),e,w);     %only do for relevant guys\

   if any(junk(contract==1)<fv(contract==1,n+1))
vk(contract==1&junk<fv(:,n+1),:)=vc(contract==1&junk<fv(:,n+1),:); %replace point with vc if function better than worst
fk(contract==1&junk<fv(:,n+1),:)=junk(junk<fv(:,n+1));
happy(contract==1&junk<fv(:,n+1))=1;  %these guys replaced with contraction
   end

end
   

% if you have accepted a new point, replace the worst point (n+1) with it

simplex(happy==1,:,n+1) = vk(happy==1,:);
fv(happy==1,n+1) = fk(happy==1);   
    
%contract

shrink=(happy==0);

if any(shrink==1)
v1 = simplex(:,:,1);

   for i=2:n+1           %only keep the best point, replace all others
           vs=v1 + a_shrink*(simplex(:,:,i)-v1);
              
   for j=1:n
     vs(:,j) = min([max([vs(:,j),x_min(:,j)],[],2),x_max(:,j)],[],2);
   end
    
   fjunk = -valfunc1(c,fspace,s(shrink==1,:),vs(shrink==1,:),e,w);
   simplex(shrink==1,:,i) = vs(shrink==1,:);
   fv(shrink==1,i) = fjunk;
       
    end
end
    
    
% order the vertices in increasing order of fv
[fv,idx] = sort(fv,2);   %idx has, for each state s=1..N, the 3rd dimension of simplex that is lowest, second lowest, ... highest
simplexjunk=zeros(size(simplex));
for i=1:n+1   %over lowest, second lowest, ... highest
   for j=1:n+1 %over current 3rd dimension of simplex
simplexjunk(idx(:,i)==j,:,i) = simplex(idx(:,i)==j,:,j);
end
end
simplex=simplexjunk;
clear simplexjunk;
x = simplex(:,:,1);
 %fprintf('%4i   %6.2e %6.2e\n',[iter,change_f,change_x])
 iter=iter+1;
end


